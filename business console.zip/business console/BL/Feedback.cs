﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business
{
    internal class Feedback
    {
        public string feedback;
        public Feedback(string fb)
        {
            feedback = fb;
        }
    }
}

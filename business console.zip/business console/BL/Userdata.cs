﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business
{
    internal class Userdata
    {
        public string uname;
        public string upassword;
        public string urole;

        public string getname() { return uname; }
        public string getpassword() { return upassword;}
        
        public string geturole() {  return urole;}
        public void setname(string name) { uname = name;}

        public  Userdata()
        {

        }
        public Userdata(string userName, string userPassword, string userRole)
        {
            this.uname = userName;
            this.upassword = userPassword;
            this.urole = userRole;
        }

        public Userdata(string userName, string userPassword)
        {
            this.uname = userName;
            this.upassword = userPassword;
            this.urole = "NA";
        }
        public bool isAdmin()
        {
            if (urole == "Admin")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
        public bool isUser()
        {
            if (urole == "User")
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
   
}
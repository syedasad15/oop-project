﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace business.BL

{
    internal class Medicine
    {
       public string medname, medquantity,medexpiry;
        public int medprice;
        public int discount;
        
    }
}

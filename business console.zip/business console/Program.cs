﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using business.BL;

namespace business
{
    internal class Program
    {
        static void Main(string[] args)
        {
           


           

            
        int usercount = 0;
            int reviewcount = 0;
            int mcount = 0, preordercount = 0, pquantity;
            string username = "", password= "", role="", pmedicine = "";
            string a = "";
            var users = new List<Userdata>();
            var medicine = new List<Medicine>();
            var review = new List<Feedback>();
            var preorder = new List<string>();
            while (a != "3")
            {
                header();
                a = decision();
                if (a == "1")
                {
                    Console.Clear();
                    header();
                    Console.Write("Enter Username (8 characters): ");
                    //username = Console.ReadLine();
                    username = Console.ReadLine();

                    Console.WriteLine("Enter Password(8 characters): ");
                    password = Console.ReadLine();

                    Console.WriteLine("Enter your Role (admin/user): ");
                    role = Console.ReadLine();

                    bool valid = usernamechecker(users, username);
                    bool Valid2 = passwordlengthchecker(password);
                    bool Valid3 = passwordcharacterchecker(password);
                    bool Valid4 = usernamelengthchecker(username);
                    bool Valid5 = usernamecharacterchecker(username);
                    bool Valid6 = rolechecker(role);
                    if (valid && Valid2 && Valid3 && Valid4 && Valid5 && Valid6)
                    {
                        signUp(users, username, password, role);
                        Console.WriteLine("Signed up SucessFully!! \n");
                        pausecreator();
                    }
                    else if (Valid2 == false)
                    {
                        Console.WriteLine("Rewrite Password of 8 characters,without having a special character/space : ");
                        pausecreator();
                    }
                    else if (Valid6 == false)
                    {
                        Console.WriteLine("Type correct role(admin/user): ");
                        pausecreator();
                    }
                    else if (Valid3 == false)
                    {
                        Console.WriteLine("Dont use special character in password");
                        pausecreator();
                    }
                    else if (Valid4 == false)
                    {
                        Console.WriteLine("Username should be of 8 characters");
                        pausecreator();
                    }
                    else if (valid == false)
                    {
                        Console.WriteLine("User already existed!");
                        pausecreator();
                    }
                }
                else if (a == "2")
                {
                    Console.Clear();
                    string name, b, pass;
                   
                    Console.WriteLine("Enter Username: ");
                  
                    name = Console.ReadLine();

                    Console.WriteLine("Enter Password: ");
                    pass = Console.ReadLine();
                    b = signIn(users, name, pass);
                    if (b == "undefined")
                    {
                        Console.WriteLine("Invalid Credentials");
                        Console.WriteLine("Press any key to continue..");
                        Console.ReadLine();
                    }
                    else
                    {
                        Console.WriteLine("Signed in Succeessfully");
                        Thread.Sleep(1000);

                        if (b == "admin")
                        {

                            string d =" ";
                            while (d != "0")
                            {

                                admininterface();
                                d = Console.ReadLine();


                                if (d == "1")
                                {

                                    Console.Clear();
                                    addstock(medicine, ref mcount);
                                    pausecreator();
                                    continue;
                                }
                                else if (d == "2")
                                {
                                    stockdisplayer(medicine, ref mcount);
                                    pausecreator();
                                    continue;
                                }
                                else if (d == "3")
                                {
                                    int del;
                                    Console.WriteLine("Enter the number of medicine you want to delete: ");
                                    del = Console.Read();
                                    deletemedicine(medicine, ref mcount, del);
                                    pausecreator();
                                }
                                else if (d == "4")
                                {
                                    meddiscount(medicine, ref mcount);
                                    pausecreator();
                                }
                                else if (d == "5")
                                {
                                    checkreview(review, ref reviewcount);
                                    pausecreator();
                                }
                                else if (d == "6")
                                {
                                    viewuser(users, ref usercount);
                                    pausecreator();
                                }
                                else if (d == "7")
                                {
                                    updateprices(medicine, ref mcount);
                                    pausecreator();
                                }
                                else if (d == "8")
                                {
                                    manageworkers();
                                    pausecreator();
                                }
                                else if (d == "9")
                                {
                                    updatenamepassadmin(users);
                                    pausecreator();
                                }
                                else if (d == "A")
                                {
                                    Console.Clear();
                                    string search;
                                    Console.WriteLine("Enter Medicine to be searched: ");
                                    search = Console.ReadLine();
                                    int index;
                                    index = medicinesearchercheck(medicine, search, ref mcount);
                                    medicinefinder(medicine, index);
                                    pausecreator();
                                }
                                else if (d == "0")
                                    break;
                                else
                                {
                                    Console.WriteLine("Invalid Input,try again!!!");
                                    pausecreator();
                                    admininterface();
                                }
                            }

                        }
                        if (b == "user")
                        {
                            char z = ' ';
                            while (z != '0')
                            {
                                Console.Clear();
                                char u;
                                header();
                                userinterface();
                                u = char.Parse(Console.ReadLine());
                                if (u == '1')
                                {
                                    Console.Clear();
                                    displayerforuser(ref mcount, medicine);

                                    pausecreator();
                                }
                                else if (u == '2')
                                {
                                    Console.Clear();
                                    meddiscountdisplay(medicine, mcount);
                                    pausecreator();
                                }
                                else if (u == '3')
                                {
                                    Console.Clear();
                                    stockdisplayer(medicine, ref mcount);

                                    Console.WriteLine("Select the medicine which you want to purchase: ");
                                    pmedicine = Console.ReadLine();
                                    Console.WriteLine("Select the medicine quantity which you want to purchase: ");
                                    pquantity = int.Parse(Console.ReadLine());
                                    makepurchase(medicine, pmedicine, pquantity);
                                    pausecreator();
                                }
                                else if (u == '4')
                                {
                                    Console.Clear();
                                    Console.WriteLine("Enter your Reviews about our pharmacy");
                                    reviewinput(review, ref reviewcount);
                                    pausecreator();
                                }
                                else if (u == '5')
                                {
                                    string newmedicine;
                                    Console.Clear();
                                    Console.WriteLine("Enter Name of a medicine which you want to pre-order");
                                    newmedicine = Console.ReadLine();
                                    // preordersaver(preorder,preordercount,newmedicine);
                                    preorder[preordercount] = newmedicine;
                                    preordercount++;
                                }
                                else if (u == '6')
                                {
                                    Console.Clear();
                                    updateorder(medicine, mcount);
                                    pausecreator();
                                }
                                else if (u == '0')
                                {
                                    break;
                                }
                                else

                                {
                                    Console.WriteLine("Invalid Input,try again!!!");
                                    Console.WriteLine("Press any key to continue..");
                                    Console.ReadKey();
                                    userinterface();
                                }



                            }

                        }
                        else if (b == "3")
                        {
                            break;
                        }
                        else
                        {

                            Console.WriteLine("Type again Correct Number\n");
                            Console.WriteLine("Press any key to continue..");
                            Console.ReadKey();
                        }

                    }
                }
            }
        }

        static void header()
        {
            Console.WriteLine("            ______________________________________________________________\n");
            Console.WriteLine("            |                                                            |\n");
            Console.WriteLine("            |                 PHARMACY MANAGEMENT SYSTEM                 |\n");
            Console.WriteLine("            |                                                            |\n");
            Console.WriteLine("            --------------------------------------------------------------\n");
        }
        static string decision()
        {
            string dec = "";

            Console.WriteLine("1-Sign Up\n");
            Console.WriteLine("2-Sign In\n");

            Console.WriteLine("3-Exit\n");

            Console.WriteLine("Press 1 to sign Up\nPress 2 to sign In\nPress 3 to Exit: ");
            dec = Console.ReadLine();
            return dec;
        }
        static bool usernamechecker(List<Userdata> users, string name)
        {
            foreach(var u in users)
            {
                if(u.uname == name)
                {
                    return false;
                }
            }
            return true;
        }
        static bool passwordlengthchecker(string pass)
        {
            if (pass.Length == 8)
                return true;
            return false;
        }
        static bool passwordcharacterchecker(string pass)
        {
            for (int i = 0; i < 8; i++)
            {
                if (!char.IsDigit(pass[i]) && !char.IsLetter(pass[i]))

                {
                    return false;
                }
            }
            return true;
        }
        static bool usernamelengthchecker(string name)
        {
            if (name.Length == 8)
                return true;
            return false;
        }
        static bool usernamecharacterchecker(string name)
        {
            {
                for (int i = 0; i < 8; i++)
                {
                    if (!char.IsDigit(name[i]) && !char.IsLetter(name[i]))
                    {
                        return false;
                    }
                }
                return true;
            }
        }
        static bool rolechecker(string role)
        {
            if (role == "admin" || role == "user")
                return true;
            return false;
        }
        static void signUp(List<Userdata> users, string username, string password, string role)
        {
            Userdata u = new Userdata();
            string connectionSting = "Server=DESKTOP-B10A0HU\\SQLEXPRESS;Database=MUSER;Trusted_Connection=True;";
            u.uname = username;
            u.upassword = password;
            u.urole = role;
            users.Add(u);
            UserDL.storeUserIntoDb(u, connectionSting);

        }
        static void pausecreator()
        {
            Console.WriteLine("Press any key to continue..");
            Console.ReadKey();
            Console.Clear();

        }
        static string signIn(List<Userdata> users, string name, string pass)
        {
            
            string Role = "undefined";
            string connectionSting = "Server=DESKTOP-B10A0HU\\SQLEXPRESS;Database=MUSER;Trusted_Connection=True;";
            List<Userdata> u2 = UserDL.GetAllUsers(connectionSting);
            
            for (int i = 0; i < users.Count; i++)
            {
                
                if (u2[i].uname== name && u2[i].upassword == pass )
                {

                    Role = users[i].urole;
                   
                }
            }
            return Role;
        }
        static void admininterface()
        {
            Console.Clear();
            header();
            Console.WriteLine("ADMIN INTERFACE\n");
            Console.WriteLine("0.Go back:  \n");
            Console.WriteLine("1.Enter Medicine Info:  \n");
            Console.WriteLine("2.Display All Stock: \n");
            Console.WriteLine("3.Delete a Medicine:  \n");
            Console.WriteLine("4.Enter Discount on Medicines:  \n");
            Console.WriteLine("5.Check Reviews:  \n");
            Console.WriteLine("6.View Users:  \n");
            Console.WriteLine("7.Update Stock:  \n");
            Console.WriteLine("8.Manage Workers: \n");
            Console.WriteLine("9.Update username/passwords: \n");
            Console.WriteLine("A.Search a medicine: \n");
            Console.WriteLine("Press 0,1,2,3,4,5,6,7,8,9 to perform following function: ");
        }
        static void addstock(List<Medicine> medicine, ref int mcount)
        {
            string addnewmedicine, newmedicinequantity, medexpiry;
            int newmedicineprice;

            Console.WriteLine("Enter name of medicine to added : ");


            addnewmedicine = Console.ReadLine();
            Console.WriteLine("Enter quantity of new medicine : ");
            newmedicinequantity = Console.ReadLine();
            Console.WriteLine("Enter expiry date of new medicine : ");


            medexpiry = Console.ReadLine();
            Console.WriteLine("Enter price of new medicine : ");

            newmedicineprice = int.Parse(Console.ReadLine());

            bool medchecker1 = namehasalphabets(addnewmedicine);
            bool medquantitychecker = quantityhasnumbers(newmedicinequantity);

            bool medexpirychecker = expiryhas2number(medexpiry);


            Medicine m = new Medicine();

            m.medname = addnewmedicine;
            m.medquantity = newmedicinequantity;
            m.medexpiry = medexpiry;
            m.medprice = newmedicineprice;
            mcount++;
        }
        static bool namehasalphabets(string addnewmedicine)
        {
            int count = 0;
            for (int i = 0; i < addnewmedicine.Length; i++)
            {
                if (char.IsLetter(addnewmedicine[i]))
                    count++;

            }
            if (count == addnewmedicine.Length)
                return true;
            return false;
        }
        static bool quantityhasnumbers(string newmedicinequantity)
        {
            int count = 0;
            for (int i = 0; i < newmedicinequantity.Length; i++)
            {
                if (char.IsDigit((newmedicinequantity[i]))) 

                count++;
            }
            if (count == newmedicinequantity.Length)
                return true;
            return false;
        }
        static bool expiryhas2number(string medexpiry)
        {
            int alphacount = 0, numbercount = 0;
            for (int i = 0; i < medexpiry.Length; i++)
            {

                if (char.IsLetter(medexpiry[i]))
                    alphacount++;
                else if (char.IsDigit(medexpiry[i]))
                    numbercount++;
            }
            if (numbercount == 4)
                return true;
            return false;
        }
        static void stockdisplayer(List<Medicine> medicine, ref int mcount)
        {

            Thread.Sleep(1000);
            Console.WriteLine("Medicine\tQuantity\tPrice\tExpiry Date\n");
            for (int i = 0; i < mcount; i++)
            {
                Console.WriteLine(i + 1 + ". " + medicine[i].medname + "\t\t" + medicine[i].medquantity + "\t\t" + medicine[i].medprice + "\t" + medicine[i].medexpiry);
                Console.WriteLine("\n");
            }
        }
        static void deletemedicine(List<Medicine> medicine, ref int mcount, int del)
        {

            Console.Clear();
            for (int i = del - 1; i < mcount; i++)
            {
                medicine[i].medname = medicine[i + 1].medname;
                medicine[i].medquantity = medicine[i + 1].medquantity;
                medicine[i].medprice = medicine[i + 1].medprice;
                medicine[i].medexpiry = medicine[i + 1].medexpiry;
            }
            mcount--;
            for (int i = 0; i < mcount; i++)
            {
                Console.WriteLine(i + 1 + ". " + medicine[i].medname + "\t\t" + medicine[i].medquantity + "\t\t" + medicine[i].medprice + "\t" + medicine[i].medexpiry);
                Console.WriteLine("\n");
            }
        }
        static void meddiscount(List<Medicine> medicine, ref int count)
        {

            for (int i = 0; i < count; i++)
            {
                Console.Clear();
                Console.WriteLine("Enter the discount on " + medicine[i].medname + ": ");
                medicine[i].discount = Console.Read();
            }
        }
        static void checkreview(List<Feedback> review, ref int reviewcount)
        {
            for (int i = 0; i < reviewcount; i++)
                Console.WriteLine(review[i] + "\n");
        }
        static void viewuser(List<Userdata> user, ref int usercount)
        {
            Console.Clear();
            header();
            Userdata m = new Userdata();
            for (int i = 0; i <= usercount; i++)
            {
                Console.WriteLine(m.uname[i] + "\t" + m.urole[i] + "\n");
            }
        }
        static void updateprices(List<Medicine> medicine, ref int count)
        {
            string medicinetobeupdated;
            int updatedprice;
            Console.WriteLine("Enter name of medicine to be updated : ");
            medicinetobeupdated = Console.ReadLine();
            Console.WriteLine("Enter the new price : ");
            updatedprice = int.Parse(Console.ReadLine());


            for (int i = 0; i < count; i++)
            {
                if (medicine[i].medname == medicinetobeupdated)
                {
                    medicine[i].medprice = updatedprice;
                    break;
                }
                else
                {
                    Console.WriteLine("Invalid medicine name ." + "\n");
                    Console.ReadKey();
                    break;
                }
            }
        }
        static void manageworkers()
        {
            int noofworkers, salary;
            Console.Clear();
            Console.WriteLine("    WORKERS REQUIREMENT >             \n");
            Console.WriteLine("*************************\n");

            Console.WriteLine("Enter no of workers required : ");
            noofworkers = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter salary of each worker : ");
            salary = int.Parse(Console.ReadLine());
            Console.ReadKey();
        }
        static void updatenamepassadmin(List<Userdata> users)
        {
            string usernametobeupdated, passwordtobeupdated, newupdatedusername, newupdatedpassword;
            Console.WriteLine("Enter old username to be updated : ");
            usernametobeupdated=Console.ReadLine();
            Console.WriteLine("Enter the old password to be updated : ");
            passwordtobeupdated = Console.ReadLine();
            Console.WriteLine("Enter new username to be updated : ");
            newupdatedusername = Console.ReadLine();
            Console.WriteLine("Enter new old password to be updated : ");
            newupdatedpassword = Console.ReadLine();
            for (int i = 0; i <= 100; i++)
            {
                if (usernametobeupdated == users[i].uname && passwordtobeupdated == users[i].upassword)
                {
                    users[i].uname = newupdatedusername;
                    users[i].uname = newupdatedpassword;
                    break;
                }
            }
        }
        static int medicinesearchercheck(List<Medicine> medicine, string searcher,ref int count)
        {
            for (int i = 0; i < count; i++)
            {
                if (medicine[i].medname == searcher)
                    return i;
            }
            return 0;
        }
        static void medicinefinder(List<Medicine> medicine, int index)
        {
            Console.WriteLine( medicine[index].medname + " " + medicine[index].medprice + " " + medicine[index].medexpiry + " " + medicine[index].medquantity + "\n");
        }

       static  void userinterface()
        {
            Console.WriteLine("USER INTERFACE\n");
            Console.WriteLine("0.Go Back:  \n");
            Console.WriteLine("1.View Medicine Names:  \n");
            Console.WriteLine("2.View Discount:  \n");
            Console.WriteLine("3.Make a Purchase: \n");
            Console.WriteLine("4.Give a Review:  \n");
            Console.WriteLine("5.Make a pre order: \n");
            Console.WriteLine("6.Update  order: \n");
            Console.WriteLine("Press 1,2,3,4,5,6,7,8 to perform following function: ");
        }
       static  void displayerforuser(ref int count, List<Medicine> medicine)
        {
            for (int i = 0; i < count; i++)
            {
                if (medicine[i].medname == "")
                {
                    break;
                }
                Console.WriteLine( "Medicine name\t\t\tMedicine price\t\t\t\t\t\tMedicine Quantity\t\t\tMedicine expiry\n");
                Console.WriteLine(i + 1 + ".  " + medicine[i].medname + "\t\t\t" + medicine[i].medprice + "\t\t\t"+ medicine[i].medquantity + "\t\t\t" + medicine[i].medexpiry[i] +"\n");
            }
        }
        static void meddiscountdisplay(List<Medicine> medicine, int count)
        {
            for (int i = 0; i < count; i++)
            {
                Console.WriteLine("Discount on Med:"+ medicine[i].medname +": ");
            }
        }
       static void makepurchase(List<Medicine> medicine, string med, int quantity )
        {

            int c = 0;
            int price = 0;
            for (int i = 0; i < 100; i++)
            {
                if (med == medicine[i].medname)
                    c = medicine[i].medname.IndexOf(med);
            }
            price = medicine[c].medprice * quantity;
            if (medicine[c].discount != 0)
            {
                price = price - (medicine[c].discount / 100);
                Console.WriteLine("You have to pay RS." +  price + "\n");
            }
            else
                Console.WriteLine("You have to pay RS." + price + "\n");
        }
       static  void reviewinput(List<Feedback> review, ref int reviewcount)
        {

             Console.Write(review[reviewcount]);
            reviewcount++;
        }

       static  void updateorder(List<Medicine> medicine, int medcount)
        {
            {
                string medicinetobeupdated;
                int updatedquantity;
                Console.WriteLine("Enter name of medicine to be updated : ");
               medicinetobeupdated=Console.ReadLine();
                Console.WriteLine("Enter the quantity you want to be updated : ");
                updatedquantity=int.Parse(Console.ReadLine());

                //  if we add invalid medicine name it will show that it is invalid.
                for (int i = 0; i <= medcount; i++)
                {
                    if (medicine[i].medname == medicinetobeupdated)
                    {
                        Console.WriteLine("You have to pay Rs." + medicine[i].medprice * updatedquantity +"\n");
                        break;
                    }
                }
            }
        }
    }
}
    

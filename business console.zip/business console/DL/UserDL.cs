﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Threading;

namespace business
{
    internal class UserDL
    {
        public static Userdata SignIn(Userdata user, string connectionString)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string searchQuery = String.Format("Select * from MUser where userName = '{0}' and userPassword = '{1}'", user.getname(), user.getpassword());
            SqlCommand command = new SqlCommand(searchQuery, connection);
            SqlDataReader data = command.ExecuteReader();
            if (data.Read())
            {

                Userdata storedUser = new Userdata(data.GetString(1), data.GetString(2), data.GetString(3));
                connection.Close();
                return storedUser;
            }
            connection.Close();
            return null;
        }



        private static bool validateUser(Userdata user, string connectionString)
        {
            SqlConnection connection = new SqlConnection(connectionString);
            connection.Open();

            string searchQuery = String.Format("Select * from MUser where userName = '{0}'", user.getname());
            SqlCommand command = new SqlCommand(searchQuery, connection);
            SqlDataReader data = command.ExecuteReader();
            bool check = data.Read();
            connection.Close();
            return check;
        }
        public static bool storeUserIntoDb(Userdata user, string connectionString)
        {
            if (!validateUser(user, connectionString))
            {
                SqlConnection connection = new SqlConnection(connectionString);
                connection.Open();
                string query = String.Format("insert into MUser (userName, userPassword, userRole) VALUES('{0}', '{1}', '{2}')", user.getname(), user.getpassword(), user.geturole());
                SqlCommand command = new SqlCommand(query, connection);
                int rowsAffected = command.ExecuteNonQuery();
                connection.Close();
                if (rowsAffected > 0)
                {
                    return true;
                }
                else
                {
                    return false;
                }

            }
            return false;
        }

        public static List<Userdata> getAllUsers(string dbConnectionString)
        {
            List<Userdata> usersList = new List<Userdata>();
            SqlConnection connection = new SqlConnection(dbConnectionString);
            connection.Open();
            string query = "SELECT * FROM MUser";
            SqlCommand command = new SqlCommand(query, connection);
            SqlDataReader reader = command.ExecuteReader();
            while (reader.Read())
            {
                string name = reader["UserName"].ToString();
                string pass = reader["UserPassword"].ToString();
                string role = reader["UserRole"].ToString();
                Userdata user = new Userdata(role, name, pass);
                //Userdata user = new Userdata(reader.GetString(1), reader.GetString(2), reader.GetString(3));
                usersList.Add(user);
            }
            connection.Close();
            return usersList;
        }


    }
}
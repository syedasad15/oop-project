﻿using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class showprices : Form
    {
        public showprices()
        {
            InitializeComponent();
            dataBind();
        }

        private void dataGridViewshowStock_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        public void dataBind()
        {
            dataGridViewshowprices.DataSource = null;
            dataGridViewshowprices.DataSource = pharmacyDL.medicineList;
            dataGridViewshowprices.Columns[1].Visible = false;
            dataGridViewshowprices.Refresh();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

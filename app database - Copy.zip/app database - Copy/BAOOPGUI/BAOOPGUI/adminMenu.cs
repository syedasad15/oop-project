﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class adminMenu : Form
    {
        public adminMenu()
        {
            InitializeComponent();
        }

        private void btnshowstock_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form showstock = new showStock();
            showstock.ShowDialog();
            this.Show();
        }

        private void btnofferdiscount_Click(object sender, EventArgs e)
        {
            this.Hide();
            offerDiscount dic = new offerDiscount();
            dic.ShowDialog();
            this.Show();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form1 signin = new Form1();
            signin.ShowDialog();
            this.Show();
        }

        private void adminMenu_Load(object sender, EventArgs e)
        {
        }

        private void btnshowfeedbacks_Click(object sender, EventArgs e)
        {
            this.Hide();
            showFeedbacks show = new showFeedbacks();
            show.ShowDialog();
            this.Show();
        }
    }
}

﻿using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class updateStock : Form
    {
        public updateStock()
        {
            InitializeComponent();
        }

        private void btnupdatestock_Click(object sender, EventArgs e)
        {
            string name = txtboxmedname.Text;
            int index = pharmacyDL.getIndex(name);
            int price = int.Parse(txtboxnewmedprice.Text);
            if (index != -1)
            {
                if (price != 0)
                {
                    pharmacyDL.updatePrice(price, index);
                    pharmacyDL.addMedicineInFile("medicine.txt");
                    lblmedupdated.Visible = true;
                    MessageBox.Show("Medicine Updated");
                    reset();
                }
                else
                {
                    lblinvalid.Visible = true;
                    MessageBox.Show("Invalid");
                    reset();
                }
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invalid");
                reset();
            }
        }
        private void reset()
        {
            txtboxmedname.Text = string.Empty;
            txtboxnewmedprice.Text = string.Empty;
            lblmedupdated.Visible = false;
            lblinvalid.Visible = false;
        }

        private void updateStock_Load(object sender, EventArgs e)
        {
            pharmacyDL.readFromFile("medicine.txt");
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Hide();
            showStock show = new showStock();
            show.ShowDialog();
            this.Show();
        }
    }
}

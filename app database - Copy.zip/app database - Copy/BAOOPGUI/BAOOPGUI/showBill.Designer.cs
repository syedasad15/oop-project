﻿namespace BAOOPGUI
{
    partial class showBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.dataGridViewshowbill = new System.Windows.Forms.DataGridView();
            this.grpboxshowbill = new System.Windows.Forms.GroupBox();
            this.lbldiscountedprice0 = new System.Windows.Forms.Label();
            this.lbltotalprice0 = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblthanks = new System.Windows.Forms.Label();
            this.lbldiscountedprice = new System.Windows.Forms.Label();
            this.lbltotalprice = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewshowbill)).BeginInit();
            this.grpboxshowbill.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(404, 29);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // dataGridViewshowbill
            // 
            this.dataGridViewshowbill.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewshowbill.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.dataGridViewshowbill.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dataGridViewshowbill.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewshowbill.Location = new System.Drawing.Point(410, 147);
            this.dataGridViewshowbill.Name = "dataGridViewshowbill";
            this.dataGridViewshowbill.ReadOnly = true;
            this.dataGridViewshowbill.Size = new System.Drawing.Size(613, 263);
            this.dataGridViewshowbill.TabIndex = 7;
            this.dataGridViewshowbill.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewshowbill_CellContentClick);
            // 
            // grpboxshowbill
            // 
            this.grpboxshowbill.BackColor = System.Drawing.Color.Transparent;
            this.grpboxshowbill.Controls.Add(this.lbldiscountedprice0);
            this.grpboxshowbill.Controls.Add(this.lbltotalprice0);
            this.grpboxshowbill.Controls.Add(this.btnexit);
            this.grpboxshowbill.Controls.Add(this.lblthanks);
            this.grpboxshowbill.Controls.Add(this.lbldiscountedprice);
            this.grpboxshowbill.Controls.Add(this.lbltotalprice);
            this.grpboxshowbill.Location = new System.Drawing.Point(410, 403);
            this.grpboxshowbill.Name = "grpboxshowbill";
            this.grpboxshowbill.Size = new System.Drawing.Size(613, 156);
            this.grpboxshowbill.TabIndex = 8;
            this.grpboxshowbill.TabStop = false;
            // 
            // lbldiscountedprice0
            // 
            this.lbldiscountedprice0.AutoSize = true;
            this.lbldiscountedprice0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountedprice0.ForeColor = System.Drawing.SystemColors.Control;
            this.lbldiscountedprice0.Location = new System.Drawing.Point(189, 46);
            this.lbldiscountedprice0.Name = "lbldiscountedprice0";
            this.lbldiscountedprice0.Size = new System.Drawing.Size(18, 20);
            this.lbldiscountedprice0.TabIndex = 5;
            this.lbldiscountedprice0.Text = "0";
            this.lbldiscountedprice0.Visible = false;
            this.lbldiscountedprice0.Click += new System.EventHandler(this.lbldiscountedprice0_Click);
            // 
            // lbltotalprice0
            // 
            this.lbltotalprice0.AutoSize = true;
            this.lbltotalprice0.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalprice0.ForeColor = System.Drawing.SystemColors.Control;
            this.lbltotalprice0.Location = new System.Drawing.Point(147, 16);
            this.lbltotalprice0.Name = "lbltotalprice0";
            this.lbltotalprice0.Size = new System.Drawing.Size(18, 20);
            this.lbltotalprice0.TabIndex = 4;
            this.lbltotalprice0.Text = "0";
            this.lbltotalprice0.Click += new System.EventHandler(this.lbltotalprice0_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Location = new System.Drawing.Point(268, 117);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(80, 25);
            this.btnexit.TabIndex = 3;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblthanks
            // 
            this.lblthanks.AutoSize = true;
            this.lblthanks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblthanks.ForeColor = System.Drawing.SystemColors.Control;
            this.lblthanks.Location = new System.Drawing.Point(33, 81);
            this.lblthanks.Name = "lblthanks";
            this.lblthanks.Size = new System.Drawing.Size(187, 20);
            this.lblthanks.TabIndex = 2;
            this.lblthanks.Text = "Thanks For Visiting Here!";
            // 
            // lbldiscountedprice
            // 
            this.lbldiscountedprice.AutoSize = true;
            this.lbldiscountedprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountedprice.ForeColor = System.Drawing.SystemColors.Control;
            this.lbldiscountedprice.Location = new System.Drawing.Point(33, 46);
            this.lbldiscountedprice.Name = "lbldiscountedprice";
            this.lbldiscountedprice.Size = new System.Drawing.Size(141, 20);
            this.lbldiscountedprice.TabIndex = 1;
            this.lbldiscountedprice.Text = "Discounted Price : ";
            this.lbldiscountedprice.Visible = false;
            // 
            // lbltotalprice
            // 
            this.lbltotalprice.AutoSize = true;
            this.lbltotalprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotalprice.ForeColor = System.Drawing.SystemColors.Control;
            this.lbltotalprice.Location = new System.Drawing.Point(33, 16);
            this.lbltotalprice.Name = "lbltotalprice";
            this.lbltotalprice.Size = new System.Drawing.Size(95, 20);
            this.lbltotalprice.TabIndex = 0;
            this.lbltotalprice.Text = "Total Price : ";
            // 
            // showBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxshowbill);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Controls.Add(this.dataGridViewshowbill);
            this.Name = "showBill";
            this.Text = "showBill";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewshowbill)).EndInit();
            this.grpboxshowbill.ResumeLayout(false);
            this.grpboxshowbill.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.DataGridView dataGridViewshowbill;
        private System.Windows.Forms.GroupBox grpboxshowbill;
        private System.Windows.Forms.Label lbltotalprice;
        private System.Windows.Forms.Label lblthanks;
        private System.Windows.Forms.Label lbldiscountedprice;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lbldiscountedprice0;
        private System.Windows.Forms.Label lbltotalprice0;
    }
}
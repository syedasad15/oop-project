﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class showBill : Form
    {
        List<customer> cart;
        public int totalBill;
        public string name;
        int price;
        public showBill(int totalBill, string name,List<customer> c)
        {
            InitializeComponent();
            this.totalBill = totalBill;
            this.name = name;
            this.cart = c; 
            if (totalBill >= 1000)
            {
                int dprice = totalBill - (totalBill / 100) * 15;
                lbldiscountedprice0.Visible = true;
                lbldiscountedprice.Visible = true;
            
                lbldiscountedprice0.Text = dprice.ToString();
            }
            lbltotalprice0.Text = totalBill.ToString();

            int index = pharmacyDL.getIndex(name);
            price = pharmacyDL.medicineList[index].getPrice();
            DataBind();
        }

        public void  DataBind()
        {
            dataGridViewshowbill.DataSource = null;
            dataGridViewshowbill.DataSource = cart;
            //DataGridViewTextBoxColumn newColumn = new DataGridViewTextBoxColumn();
            //newColumn.HeaderText = "Price";
            //dataGridViewshowbill.Columns.Add(newColumn);
            //int columnindex = dataGridViewshowbill.Columns.IndexOf(newColumn);
            //dataGridViewshowbill.Rows[0].Cells[columnindex].Value = price;
        }

        private void dataGridViewshowbill_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void lbldiscountedprice0_Click(object sender, EventArgs e)

        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
            customerMenu custMenu = new customerMenu();
            custMenu.ShowDialog();
            this.Show();
        }

        private void lbltotalprice0_Click(object sender, EventArgs e)
        {

        }
    }
}

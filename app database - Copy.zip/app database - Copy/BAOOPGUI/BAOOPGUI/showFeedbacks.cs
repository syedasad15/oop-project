﻿using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class showFeedbacks : Form
    {
        public showFeedbacks()
        {
            InitializeComponent();
            dataBind();
            //dataGridViewshowFeedbacks.DataSource = feedbackDL.feedbackDLList;
        }

        private void showFeedbacks_Load(object sender, EventArgs e)
        {
            //dataGridViewshowFeedbacks.DataSource = feedbackDL.feedbackDLList;
        }
        public void dataBind()
        {
            dataGridViewshowFeedbacks.DataSource = null;
            dataGridViewshowFeedbacks.DataSource = feedbackDL.feedbackDLList;
            dataGridViewshowFeedbacks.Refresh();
        }

        private void dataGridViewshowFeedbacks_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Hide();
            showStock show = new showStock();
            show.ShowDialog();
            this.Show();
        }

        private void lblmsnpharmacy_Click(object sender, EventArgs e)
        {

        }
    }
}

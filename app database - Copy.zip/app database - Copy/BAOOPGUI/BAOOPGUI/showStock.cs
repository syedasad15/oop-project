﻿using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class showStock : Form
    {
        public showStock()
        {
            InitializeComponent();
            dataBind();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void showStock_Load(object sender, EventArgs e)
        {

        }
        public void dataBind()
        {
            dataGridViewshowStock.DataSource = null;
            dataGridViewshowStock.DataSource = pharmacyDL.medicineList;
            dataGridViewshowStock.Refresh();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
            adminMenu adminMenu = new adminMenu();
            adminMenu.ShowDialog();
            this.Show();
        }

        private void btnaddstock_Click(object sender, EventArgs e)
        {
            this.Hide();
            addStock add = new addStock();
            add.ShowDialog();
            this.Show();
        }

        private void btndeletestock_Click(object sender, EventArgs e)
        {
            this.Hide();
            deleteStock delete = new deleteStock();
            delete.ShowDialog();
            this.Show();
        }

        private void btnupdatestock_Click(object sender, EventArgs e)
        {
            this.Hide();
            updateStock update = new updateStock();
            update.ShowDialog();
            this.Show();
        }
    }
}

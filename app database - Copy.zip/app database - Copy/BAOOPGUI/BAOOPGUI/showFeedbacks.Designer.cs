﻿namespace BAOOPGUI
{
    partial class showFeedbacks
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewshowFeedbacks = new System.Windows.Forms.DataGridView();
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewshowFeedbacks)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewshowFeedbacks
            // 
            this.dataGridViewshowFeedbacks.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewshowFeedbacks.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.dataGridViewshowFeedbacks.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewshowFeedbacks.Location = new System.Drawing.Point(351, 164);
            this.dataGridViewshowFeedbacks.Name = "dataGridViewshowFeedbacks";
            this.dataGridViewshowFeedbacks.ReadOnly = true;
            this.dataGridViewshowFeedbacks.Size = new System.Drawing.Size(729, 414);
            this.dataGridViewshowFeedbacks.TabIndex = 1;
            this.dataGridViewshowFeedbacks.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridViewshowFeedbacks_CellContentClick);
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(413, 42);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            this.lblmsnpharmacy.Click += new System.EventHandler(this.lblmsnpharmacy_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(641, 593);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(156, 33);
            this.btnexit.TabIndex = 20;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // showFeedbacks
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Controls.Add(this.dataGridViewshowFeedbacks);
            this.Name = "showFeedbacks";
            this.Text = "showFeedbacks";
            this.Load += new System.EventHandler(this.showFeedbacks_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewshowFeedbacks)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewshowFeedbacks;
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.Button btnexit;
    }
}
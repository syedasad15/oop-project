﻿namespace BAOOPGUI
{
    partial class giveFeedback
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxgivefeedback = new System.Windows.Forms.GroupBox();
            this.lblfeedbackadded = new System.Windows.Forms.Label();
            this.txtboxfeedback = new System.Windows.Forms.TextBox();
            this.lblfeedback = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btnEnter = new System.Windows.Forms.Button();
            this.txtboxname = new System.Windows.Forms.TextBox();
            this.lblname = new System.Windows.Forms.Label();
            this.lblgivefeedbak = new System.Windows.Forms.Label();
            this.grpboxgivefeedback.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(340, 81);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxgivefeedback
            // 
            this.grpboxgivefeedback.BackColor = System.Drawing.Color.Transparent;
            this.grpboxgivefeedback.Controls.Add(this.lblfeedbackadded);
            this.grpboxgivefeedback.Controls.Add(this.txtboxfeedback);
            this.grpboxgivefeedback.Controls.Add(this.lblfeedback);
            this.grpboxgivefeedback.Controls.Add(this.btnexit);
            this.grpboxgivefeedback.Controls.Add(this.lblinvalid);
            this.grpboxgivefeedback.Controls.Add(this.btnEnter);
            this.grpboxgivefeedback.Controls.Add(this.txtboxname);
            this.grpboxgivefeedback.Controls.Add(this.lblname);
            this.grpboxgivefeedback.Controls.Add(this.lblgivefeedbak);
            this.grpboxgivefeedback.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grpboxgivefeedback.Location = new System.Drawing.Point(319, 194);
            this.grpboxgivefeedback.Name = "grpboxgivefeedback";
            this.grpboxgivefeedback.Size = new System.Drawing.Size(673, 491);
            this.grpboxgivefeedback.TabIndex = 10;
            this.grpboxgivefeedback.TabStop = false;
            // 
            // lblfeedbackadded
            // 
            this.lblfeedbackadded.AutoSize = true;
            this.lblfeedbackadded.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfeedbackadded.ForeColor = System.Drawing.Color.Red;
            this.lblfeedbackadded.Location = new System.Drawing.Point(308, 426);
            this.lblfeedbackadded.Name = "lblfeedbackadded";
            this.lblfeedbackadded.Size = new System.Drawing.Size(115, 17);
            this.lblfeedbackadded.TabIndex = 17;
            this.lblfeedbackadded.Text = "Feedback Added";
            this.lblfeedbackadded.Visible = false;
            // 
            // txtboxfeedback
            // 
            this.txtboxfeedback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxfeedback.Location = new System.Drawing.Point(171, 241);
            this.txtboxfeedback.Multiline = true;
            this.txtboxfeedback.Name = "txtboxfeedback";
            this.txtboxfeedback.Size = new System.Drawing.Size(409, 97);
            this.txtboxfeedback.TabIndex = 16;
            // 
            // lblfeedback
            // 
            this.lblfeedback.AutoSize = true;
            this.lblfeedback.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblfeedback.ForeColor = System.Drawing.Color.Black;
            this.lblfeedback.Location = new System.Drawing.Point(34, 250);
            this.lblfeedback.Name = "lblfeedback";
            this.lblfeedback.Size = new System.Drawing.Size(70, 17);
            this.lblfeedback.TabIndex = 15;
            this.lblfeedback.Text = "Feedback";
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(453, 360);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(127, 33);
            this.btnexit.TabIndex = 12;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(308, 443);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            // 
            // btnEnter
            // 
            this.btnEnter.BackColor = System.Drawing.Color.Transparent;
            this.btnEnter.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEnter.Location = new System.Drawing.Point(171, 360);
            this.btnEnter.Name = "btnEnter";
            this.btnEnter.Size = new System.Drawing.Size(127, 33);
            this.btnEnter.TabIndex = 5;
            this.btnEnter.Text = "Enter";
            this.btnEnter.UseVisualStyleBackColor = false;
            this.btnEnter.Click += new System.EventHandler(this.btnEnter_Click);
            // 
            // txtboxname
            // 
            this.txtboxname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxname.Location = new System.Drawing.Point(171, 158);
            this.txtboxname.Name = "txtboxname";
            this.txtboxname.Size = new System.Drawing.Size(409, 26);
            this.txtboxname.TabIndex = 3;
            // 
            // lblname
            // 
            this.lblname.AutoSize = true;
            this.lblname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblname.ForeColor = System.Drawing.Color.Black;
            this.lblname.Location = new System.Drawing.Point(34, 164);
            this.lblname.Name = "lblname";
            this.lblname.Size = new System.Drawing.Size(45, 17);
            this.lblname.TabIndex = 1;
            this.lblname.Text = "Name";
            // 
            // lblgivefeedbak
            // 
            this.lblgivefeedbak.AutoSize = true;
            this.lblgivefeedbak.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgivefeedbak.ForeColor = System.Drawing.Color.Black;
            this.lblgivefeedbak.Location = new System.Drawing.Point(275, 41);
            this.lblgivefeedbak.Name = "lblgivefeedbak";
            this.lblgivefeedbak.Size = new System.Drawing.Size(210, 31);
            this.lblgivefeedbak.TabIndex = 0;
            this.lblgivefeedbak.Text = "Give Feedback";
            // 
            // giveFeedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxgivefeedback);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "giveFeedback";
            this.Text = "giveFeedback";
            this.grpboxgivefeedback.ResumeLayout(false);
            this.grpboxgivefeedback.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxgivefeedback;
        private System.Windows.Forms.Label lblfeedbackadded;
        private System.Windows.Forms.TextBox txtboxfeedback;
        private System.Windows.Forms.Label lblfeedback;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Button btnEnter;
        private System.Windows.Forms.TextBox txtboxname;
        private System.Windows.Forms.Label lblname;
        private System.Windows.Forms.Label lblgivefeedbak;
    }
}
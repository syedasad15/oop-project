﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class customerMenu : Form
    {
        public customerMenu()
        {
            InitializeComponent();
        }

        private void btncheckbill_Click(object sender, EventArgs e)
        {
            this.Hide();
            Form check = new checkBill();
            check.ShowDialog();
            this.Show();
        }

        private void btnupdatepassword_Click(object sender, EventArgs e)
        {
            this.Hide();
            changePasswordCustomer change = new changePasswordCustomer();
            change.ShowDialog();
            this.Show();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btngivefeedback_Click(object sender, EventArgs e)
        {
            this.Hide();
            giveFeedback f = new giveFeedback();
            f.ShowDialog();
            this.Show();
        }

        private void btncheckprices_Click(object sender, EventArgs e)
        {
            this.Hide();
            showprices show = new showprices();
            show.ShowDialog();
            this.Show();
        }
    }
}

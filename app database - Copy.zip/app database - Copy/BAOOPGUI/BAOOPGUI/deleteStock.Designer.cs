﻿namespace BAOOPGUI
{
    partial class deleteStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxdeletestock = new System.Windows.Forms.GroupBox();
            this.lblmeddeleted = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btndeletestock = new System.Windows.Forms.Button();
            this.txtboxmedname = new System.Windows.Forms.TextBox();
            this.lblmedname = new System.Windows.Forms.Label();
            this.lbldeletestock = new System.Windows.Forms.Label();
            this.grpboxdeletestock.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(340, 71);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxdeletestock
            // 
            this.grpboxdeletestock.BackColor = System.Drawing.Color.Transparent;
            this.grpboxdeletestock.Controls.Add(this.lblmeddeleted);
            this.grpboxdeletestock.Controls.Add(this.btnexit);
            this.grpboxdeletestock.Controls.Add(this.lblinvalid);
            this.grpboxdeletestock.Controls.Add(this.btndeletestock);
            this.grpboxdeletestock.Controls.Add(this.txtboxmedname);
            this.grpboxdeletestock.Controls.Add(this.lblmedname);
            this.grpboxdeletestock.Controls.Add(this.lbldeletestock);
            this.grpboxdeletestock.Location = new System.Drawing.Point(319, 194);
            this.grpboxdeletestock.Name = "grpboxdeletestock";
            this.grpboxdeletestock.Size = new System.Drawing.Size(673, 491);
            this.grpboxdeletestock.TabIndex = 8;
            this.grpboxdeletestock.TabStop = false;
            // 
            // lblmeddeleted
            // 
            this.lblmeddeleted.AutoSize = true;
            this.lblmeddeleted.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmeddeleted.ForeColor = System.Drawing.Color.Red;
            this.lblmeddeleted.Location = new System.Drawing.Point(308, 415);
            this.lblmeddeleted.Name = "lblmeddeleted";
            this.lblmeddeleted.Size = new System.Drawing.Size(117, 17);
            this.lblmeddeleted.TabIndex = 14;
            this.lblmeddeleted.Text = "Medicine Deleted";
            this.lblmeddeleted.Visible = false;
            this.lblmeddeleted.Click += new System.EventHandler(this.lblmeddeleted_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(443, 299);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(127, 33);
            this.btnexit.TabIndex = 12;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(302, 369);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            // 
            // btndeletestock
            // 
            this.btndeletestock.BackColor = System.Drawing.Color.Transparent;
            this.btndeletestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeletestock.Location = new System.Drawing.Point(161, 299);
            this.btndeletestock.Name = "btndeletestock";
            this.btndeletestock.Size = new System.Drawing.Size(127, 33);
            this.btndeletestock.TabIndex = 5;
            this.btndeletestock.Text = "Delete";
            this.btndeletestock.UseVisualStyleBackColor = false;
            this.btndeletestock.Click += new System.EventHandler(this.btndeletestock_Click);
            // 
            // txtboxmedname
            // 
            this.txtboxmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedname.Location = new System.Drawing.Point(161, 139);
            this.txtboxmedname.Name = "txtboxmedname";
            this.txtboxmedname.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedname.TabIndex = 3;
            // 
            // lblmedname
            // 
            this.lblmedname.AutoSize = true;
            this.lblmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedname.ForeColor = System.Drawing.Color.Black;
            this.lblmedname.Location = new System.Drawing.Point(34, 145);
            this.lblmedname.Name = "lblmedname";
            this.lblmedname.Size = new System.Drawing.Size(105, 17);
            this.lblmedname.TabIndex = 1;
            this.lblmedname.Text = "Medicine Name";
            // 
            // lbldeletestock
            // 
            this.lbldeletestock.AutoSize = true;
            this.lbldeletestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldeletestock.ForeColor = System.Drawing.Color.Teal;
            this.lbldeletestock.Location = new System.Drawing.Point(275, 41);
            this.lbldeletestock.Name = "lbldeletestock";
            this.lbldeletestock.Size = new System.Drawing.Size(181, 31);
            this.lbldeletestock.TabIndex = 0;
            this.lbldeletestock.Text = "Delete Stock";
            // 
            // deleteStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxdeletestock);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "deleteStock";
            this.Text = "deleteStock";
            this.Load += new System.EventHandler(this.deleteStock_Load);
            this.grpboxdeletestock.ResumeLayout(false);
            this.grpboxdeletestock.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxdeletestock;
        private System.Windows.Forms.Label lblmeddeleted;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Button btndeletestock;
        private System.Windows.Forms.TextBox txtboxmedname;
        private System.Windows.Forms.Label lblmedname;
        private System.Windows.Forms.Label lbldeletestock;
    }
}
﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class giveFeedback : Form
    {
        public giveFeedback()
        {
            InitializeComponent();
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            string name = txtboxname.Text;
            string feedBack = txtboxfeedback.Text;
            if(name != string.Empty && feedBack  != string.Empty)
            {
                feedback f = new feedback(name, feedBack);
                feedbackDL.addInList(f);
                feedbackDL.addFeedBackDataInFile("feedback.txt");
                lblfeedbackadded.Visible = true;
                MessageBox.Show("Feedback Added.");
                this.Close();
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invalid Input.");
                this.Close();
            }
        }
    }
}

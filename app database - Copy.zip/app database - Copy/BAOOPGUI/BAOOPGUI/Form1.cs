﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            pharmacyDL.readFromFile("medicine.txt");
            //feedbackDL.readFromFile("feedback.txt");
           
        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
            string connectionString = "Server=DESKTOP-B10A0HU\\SQLEXPRESS;Database=MUSER;Trusted_Connection=True;";
            //string connectionString = @"Data Source=(local);Initial Catalog=MUSER;Integrated Security=True";
            UserDL.Users= UserDL.getAllUsers(connectionString);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form SignUp = new SignUp();
            SignUp.ShowDialog();
            this.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = txtboxusername.Text;
            string password = txtboxpassword.Text;
            signIn signin = new signIn(name,password);
            string role =  UserDL.GetRoleForSignIn(signin);
            if(role == "admin")
            {
                MessageBox.Show("Sign In Successfull.");
                this.Hide();
                adminMenu menu = new adminMenu();
                menu.ShowDialog();
                this.Show();
            }
            else if(role == "customer")
            {
                MessageBox.Show("Sign In Successfull.");
                this.Hide();
                Form userform = new customerMenu();
                userform.ShowDialog();
                this.Show();
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invalid Credentials.");
                reset();
            }

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }
        private void reset()
        {
            txtboxusername.Text = string.Empty;
            txtboxpassword.Text = string.Empty;
            lbldonthaveaccount.Visible = false;
            lblinvalid.Visible = false;
            lblsignedinsuccessful.Visible = false;
        }

        private void txtboxpassword_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblsignin_Click(object sender, EventArgs e)
        {

        }
    }
}

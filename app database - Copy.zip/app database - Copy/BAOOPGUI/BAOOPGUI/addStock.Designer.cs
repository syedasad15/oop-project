﻿namespace BAOOPGUI
{
    partial class addStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxaddstock = new System.Windows.Forms.GroupBox();
            this.lblmedadded = new System.Windows.Forms.Label();
            this.lblalredyexit = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblmedquantity = new System.Windows.Forms.Label();
            this.txtboxmedquantity = new System.Windows.Forms.TextBox();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btnaddstock = new System.Windows.Forms.Button();
            this.txtboxmedprice = new System.Windows.Forms.TextBox();
            this.txtboxmedname = new System.Windows.Forms.TextBox();
            this.lblmedprice = new System.Windows.Forms.Label();
            this.lblmedname = new System.Windows.Forms.Label();
            this.lbladdstock = new System.Windows.Forms.Label();
            this.grpboxaddstock.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(340, 100);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxaddstock
            // 
            this.grpboxaddstock.BackColor = System.Drawing.Color.Transparent;
            this.grpboxaddstock.Controls.Add(this.lblmedadded);
            this.grpboxaddstock.Controls.Add(this.lblalredyexit);
            this.grpboxaddstock.Controls.Add(this.btnexit);
            this.grpboxaddstock.Controls.Add(this.lblmedquantity);
            this.grpboxaddstock.Controls.Add(this.txtboxmedquantity);
            this.grpboxaddstock.Controls.Add(this.lblinvalid);
            this.grpboxaddstock.Controls.Add(this.btnaddstock);
            this.grpboxaddstock.Controls.Add(this.txtboxmedprice);
            this.grpboxaddstock.Controls.Add(this.txtboxmedname);
            this.grpboxaddstock.Controls.Add(this.lblmedprice);
            this.grpboxaddstock.Controls.Add(this.lblmedname);
            this.grpboxaddstock.Controls.Add(this.lbladdstock);
            this.grpboxaddstock.Location = new System.Drawing.Point(319, 194);
            this.grpboxaddstock.Name = "grpboxaddstock";
            this.grpboxaddstock.Size = new System.Drawing.Size(673, 491);
            this.grpboxaddstock.TabIndex = 7;
            this.grpboxaddstock.TabStop = false;
            // 
            // lblmedadded
            // 
            this.lblmedadded.AutoSize = true;
            this.lblmedadded.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedadded.ForeColor = System.Drawing.Color.Red;
            this.lblmedadded.Location = new System.Drawing.Point(308, 460);
            this.lblmedadded.Name = "lblmedadded";
            this.lblmedadded.Size = new System.Drawing.Size(109, 17);
            this.lblmedadded.TabIndex = 14;
            this.lblmedadded.Text = "Medicine Added";
            this.lblmedadded.Visible = false;
            // 
            // lblalredyexit
            // 
            this.lblalredyexit.AutoSize = true;
            this.lblalredyexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblalredyexit.ForeColor = System.Drawing.Color.Red;
            this.lblalredyexit.Location = new System.Drawing.Point(308, 471);
            this.lblalredyexit.Name = "lblalredyexit";
            this.lblalredyexit.Size = new System.Drawing.Size(141, 17);
            this.lblalredyexit.TabIndex = 13;
            this.lblalredyexit.Text = "Medicine Alredy Exist";
            this.lblalredyexit.Visible = false;
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(443, 374);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(127, 33);
            this.btnexit.TabIndex = 12;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblmedquantity
            // 
            this.lblmedquantity.AutoSize = true;
            this.lblmedquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedquantity.ForeColor = System.Drawing.Color.Black;
            this.lblmedquantity.Location = new System.Drawing.Point(34, 298);
            this.lblmedquantity.Name = "lblmedquantity";
            this.lblmedquantity.Size = new System.Drawing.Size(121, 17);
            this.lblmedquantity.TabIndex = 11;
            this.lblmedquantity.Text = "Medicine Quantity";
            // 
            // txtboxmedquantity
            // 
            this.txtboxmedquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedquantity.Location = new System.Drawing.Point(161, 292);
            this.txtboxmedquantity.Name = "txtboxmedquantity";
            this.txtboxmedquantity.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedquantity.TabIndex = 10;
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(308, 443);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            this.lblinvalid.Click += new System.EventHandler(this.lblinvalid_Click);
            // 
            // btnaddstock
            // 
            this.btnaddstock.BackColor = System.Drawing.Color.Transparent;
            this.btnaddstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddstock.Location = new System.Drawing.Point(161, 374);
            this.btnaddstock.Name = "btnaddstock";
            this.btnaddstock.Size = new System.Drawing.Size(127, 33);
            this.btnaddstock.TabIndex = 5;
            this.btnaddstock.Text = "Add";
            this.btnaddstock.UseVisualStyleBackColor = false;
            this.btnaddstock.Click += new System.EventHandler(this.btnaddstock_Click);
            // 
            // txtboxmedprice
            // 
            this.txtboxmedprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedprice.Location = new System.Drawing.Point(161, 215);
            this.txtboxmedprice.Name = "txtboxmedprice";
            this.txtboxmedprice.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedprice.TabIndex = 4;
            // 
            // txtboxmedname
            // 
            this.txtboxmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedname.Location = new System.Drawing.Point(161, 139);
            this.txtboxmedname.Name = "txtboxmedname";
            this.txtboxmedname.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedname.TabIndex = 3;
            // 
            // lblmedprice
            // 
            this.lblmedprice.AutoSize = true;
            this.lblmedprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedprice.ForeColor = System.Drawing.Color.Black;
            this.lblmedprice.Location = new System.Drawing.Point(34, 221);
            this.lblmedprice.Name = "lblmedprice";
            this.lblmedprice.Size = new System.Drawing.Size(100, 17);
            this.lblmedprice.TabIndex = 2;
            this.lblmedprice.Text = "Medicine Price";
            // 
            // lblmedname
            // 
            this.lblmedname.AutoSize = true;
            this.lblmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedname.ForeColor = System.Drawing.Color.Black;
            this.lblmedname.Location = new System.Drawing.Point(34, 145);
            this.lblmedname.Name = "lblmedname";
            this.lblmedname.Size = new System.Drawing.Size(105, 17);
            this.lblmedname.TabIndex = 1;
            this.lblmedname.Text = "Medicine Name";
            // 
            // lbladdstock
            // 
            this.lbladdstock.AutoSize = true;
            this.lbladdstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdstock.ForeColor = System.Drawing.Color.Teal;
            this.lbladdstock.Location = new System.Drawing.Point(275, 41);
            this.lbladdstock.Name = "lbladdstock";
            this.lbladdstock.Size = new System.Drawing.Size(147, 31);
            this.lbladdstock.TabIndex = 0;
            this.lbladdstock.Text = "Add Stock";
            // 
            // addStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxaddstock);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "addStock";
            this.Text = "addStock";
            this.grpboxaddstock.ResumeLayout(false);
            this.grpboxaddstock.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxaddstock;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Button btnaddstock;
        private System.Windows.Forms.TextBox txtboxmedprice;
        private System.Windows.Forms.TextBox txtboxmedname;
        private System.Windows.Forms.Label lblmedprice;
        private System.Windows.Forms.Label lblmedname;
        private System.Windows.Forms.Label lbladdstock;
        private System.Windows.Forms.Label lblmedquantity;
        private System.Windows.Forms.TextBox txtboxmedquantity;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblalredyexit;
        private System.Windows.Forms.Label lblmedadded;
    }
}
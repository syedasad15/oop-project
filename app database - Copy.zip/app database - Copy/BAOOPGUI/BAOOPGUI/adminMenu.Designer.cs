﻿namespace BAOOPGUI
{
    partial class adminMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnexit = new System.Windows.Forms.Button();
            this.btnshowstock = new System.Windows.Forms.Button();
            this.btnshowfeedbacks = new System.Windows.Forms.Button();
            this.btnofferdiscount = new System.Windows.Forms.Button();
            this.lblmanagermenu = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(352, 56);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.btnexit);
            this.groupBox1.Controls.Add(this.btnshowstock);
            this.groupBox1.Controls.Add(this.btnshowfeedbacks);
            this.groupBox1.Controls.Add(this.btnofferdiscount);
            this.groupBox1.Controls.Add(this.lblmanagermenu);
            this.groupBox1.Location = new System.Drawing.Point(474, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(430, 527);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(130, 401);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(156, 33);
            this.btnexit.TabIndex = 15;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btnshowstock
            // 
            this.btnshowstock.BackColor = System.Drawing.Color.Transparent;
            this.btnshowstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshowstock.Location = new System.Drawing.Point(130, 138);
            this.btnshowstock.Name = "btnshowstock";
            this.btnshowstock.Size = new System.Drawing.Size(156, 33);
            this.btnshowstock.TabIndex = 14;
            this.btnshowstock.Text = "Show Stock";
            this.btnshowstock.UseVisualStyleBackColor = false;
            this.btnshowstock.Click += new System.EventHandler(this.btnshowstock_Click);
            // 
            // btnshowfeedbacks
            // 
            this.btnshowfeedbacks.BackColor = System.Drawing.Color.Transparent;
            this.btnshowfeedbacks.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnshowfeedbacks.Location = new System.Drawing.Point(130, 314);
            this.btnshowfeedbacks.Name = "btnshowfeedbacks";
            this.btnshowfeedbacks.Size = new System.Drawing.Size(156, 34);
            this.btnshowfeedbacks.TabIndex = 13;
            this.btnshowfeedbacks.Text = "Show Feedbacks";
            this.btnshowfeedbacks.UseVisualStyleBackColor = false;
            this.btnshowfeedbacks.Click += new System.EventHandler(this.btnshowfeedbacks_Click);
            // 
            // btnofferdiscount
            // 
            this.btnofferdiscount.BackColor = System.Drawing.Color.Transparent;
            this.btnofferdiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnofferdiscount.Location = new System.Drawing.Point(130, 228);
            this.btnofferdiscount.Name = "btnofferdiscount";
            this.btnofferdiscount.Size = new System.Drawing.Size(156, 33);
            this.btnofferdiscount.TabIndex = 12;
            this.btnofferdiscount.Text = "Offer Discount";
            this.btnofferdiscount.UseVisualStyleBackColor = false;
            this.btnofferdiscount.Click += new System.EventHandler(this.btnofferdiscount_Click);
            // 
            // lblmanagermenu
            // 
            this.lblmanagermenu.AutoSize = true;
            this.lblmanagermenu.BackColor = System.Drawing.Color.Transparent;
            this.lblmanagermenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmanagermenu.ForeColor = System.Drawing.Color.Teal;
            this.lblmanagermenu.Location = new System.Drawing.Point(81, 29);
            this.lblmanagermenu.Name = "lblmanagermenu";
            this.lblmanagermenu.Size = new System.Drawing.Size(257, 39);
            this.lblmanagermenu.TabIndex = 0;
            this.lblmanagermenu.Text = "Manager Menu";
            // 
            // adminMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "adminMenu";
            this.Text = "adminMenu";
            this.Load += new System.EventHandler(this.adminMenu_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblmanagermenu;
        private System.Windows.Forms.Button btnshowstock;
        private System.Windows.Forms.Button btnshowfeedbacks;
        private System.Windows.Forms.Button btnofferdiscount;
        private System.Windows.Forms.Button btnexit;
    }
}
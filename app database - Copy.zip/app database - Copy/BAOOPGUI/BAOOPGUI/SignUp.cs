﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace BAOOPGUI
{
    public partial class SignUp : Form
    {
        public SignUp()
        {
            InitializeComponent();
        }

        private void SignUp_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void btnsignup_Click(object sender, EventArgs e)
        {
            string username = txtboxusername.Text;
            string password = txtboxpassword.Text;
            string role = txtboxrole.Text;
            if(username != string.Empty && password != string.Empty && role != string.Empty) 
            {
                if(role == "admin" || role == "customer")
                {
                    signUp signup = new signUp(role,username, password);
                    bool check = UserDL.CheckValid(signup);
                    if(check)
                    {
                        UserDL.AddUserInList(signup);
                        UserDL.storeUserIntoDb(signup);
                        lblsignedupsuccessfull.Visible = true;
                        MessageBox.Show("Signed Up");
                        reset();
                    }
                    else
                    {
                        lblinvalid.Visible = true;
                        MessageBox.Show("Invalid");
                        reset();
                    }
                }
                else 
                {
                    lblinvalid.Visible = true;
                    MessageBox.Show("Invalid");
                    reset();
                }
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invalid");
                reset();
            }
        }

        private void linklblsinin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            this.Hide();
            Form1 signin = new Form1();
            signin.ShowDialog();
            this.Show();

        }
        private void reset()
        {
            txtboxusername.Text = string.Empty;
            txtboxpassword.Text = string.Empty;
            txtboxrole.Text = string.Empty;
            lblalredyhaveaccount.Visible = false;
            lblinvalid.Visible = false;
            lblsignedupsuccessfull.Visible = false;

        }
    }
}

﻿namespace BAOOPGUI
{
    partial class offerDiscount
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxofferdiscount = new System.Windows.Forms.GroupBox();
            this.lbldiscountcontent3 = new System.Windows.Forms.Label();
            this.lbldiscountcontent2 = new System.Windows.Forms.Label();
            this.lbldiscountcontent = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblofferdiscount = new System.Windows.Forms.Label();
            this.grpboxofferdiscount.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(368, 120);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxofferdiscount
            // 
            this.grpboxofferdiscount.BackColor = System.Drawing.Color.Transparent;
            this.grpboxofferdiscount.Controls.Add(this.lbldiscountcontent3);
            this.grpboxofferdiscount.Controls.Add(this.lbldiscountcontent2);
            this.grpboxofferdiscount.Controls.Add(this.lbldiscountcontent);
            this.grpboxofferdiscount.Controls.Add(this.btnexit);
            this.grpboxofferdiscount.Controls.Add(this.lblofferdiscount);
            this.grpboxofferdiscount.Location = new System.Drawing.Point(474, 243);
            this.grpboxofferdiscount.Name = "grpboxofferdiscount";
            this.grpboxofferdiscount.Size = new System.Drawing.Size(430, 434);
            this.grpboxofferdiscount.TabIndex = 5;
            this.grpboxofferdiscount.TabStop = false;
            // 
            // lbldiscountcontent3
            // 
            this.lbldiscountcontent3.AutoSize = true;
            this.lbldiscountcontent3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountcontent3.ForeColor = System.Drawing.Color.Black;
            this.lbldiscountcontent3.Location = new System.Drawing.Point(84, 232);
            this.lbldiscountcontent3.Name = "lbldiscountcontent3";
            this.lbldiscountcontent3.Size = new System.Drawing.Size(219, 20);
            this.lbldiscountcontent3.TabIndex = 18;
            this.lbldiscountcontent3.Text = "any   customer   on   total   bill.";
            // 
            // lbldiscountcontent2
            // 
            this.lbldiscountcontent2.AutoSize = true;
            this.lbldiscountcontent2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountcontent2.ForeColor = System.Drawing.Color.Black;
            this.lbldiscountcontent2.Location = new System.Drawing.Point(84, 189);
            this.lbldiscountcontent2.Name = "lbldiscountcontent2";
            this.lbldiscountcontent2.Size = new System.Drawing.Size(225, 20);
            this.lbldiscountcontent2.TabIndex = 17;
            this.lbldiscountcontent2.Text = "15%   discount   is   offered   to";
            // 
            // lbldiscountcontent
            // 
            this.lbldiscountcontent.AutoSize = true;
            this.lbldiscountcontent.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbldiscountcontent.ForeColor = System.Drawing.Color.Black;
            this.lbldiscountcontent.Location = new System.Drawing.Point(84, 138);
            this.lbldiscountcontent.Name = "lbldiscountcontent";
            this.lbldiscountcontent.Size = new System.Drawing.Size(241, 20);
            this.lbldiscountcontent.TabIndex = 16;
            this.lbldiscountcontent.Text = "If  Bill    is    greater    than    1000";
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(128, 326);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(156, 33);
            this.btnexit.TabIndex = 15;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblofferdiscount
            // 
            this.lblofferdiscount.AutoSize = true;
            this.lblofferdiscount.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblofferdiscount.ForeColor = System.Drawing.Color.Teal;
            this.lblofferdiscount.Location = new System.Drawing.Point(81, 29);
            this.lblofferdiscount.Name = "lblofferdiscount";
            this.lblofferdiscount.Size = new System.Drawing.Size(247, 39);
            this.lblofferdiscount.TabIndex = 0;
            this.lblofferdiscount.Text = "Offer Discount";
            // 
            // offerDiscount
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxofferdiscount);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "offerDiscount";
            this.Text = "offerDiscount";
            this.Load += new System.EventHandler(this.offerDiscount_Load);
            this.grpboxofferdiscount.ResumeLayout(false);
            this.grpboxofferdiscount.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxofferdiscount;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblofferdiscount;
        private System.Windows.Forms.Label lbldiscountcontent;
        private System.Windows.Forms.Label lbldiscountcontent2;
        private System.Windows.Forms.Label lbldiscountcontent3;
    }
}
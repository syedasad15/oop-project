﻿namespace BAOOPGUI
{
    partial class SignUp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpboxsignup = new System.Windows.Forms.GroupBox();
            this.linklblsinin = new System.Windows.Forms.LinkLabel();
            this.lblalredyhaveaccount = new System.Windows.Forms.Label();
            this.lblsignedupsuccessfull = new System.Windows.Forms.Label();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btnsignup = new System.Windows.Forms.Button();
            this.txtboxrole = new System.Windows.Forms.TextBox();
            this.txtboxpassword = new System.Windows.Forms.TextBox();
            this.txtboxusername = new System.Windows.Forms.TextBox();
            this.lblrole = new System.Windows.Forms.Label();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.lblsignup = new System.Windows.Forms.Label();
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxsignup.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpboxsignup
            // 
            this.grpboxsignup.BackColor = System.Drawing.Color.Transparent;
            this.grpboxsignup.Controls.Add(this.linklblsinin);
            this.grpboxsignup.Controls.Add(this.lblalredyhaveaccount);
            this.grpboxsignup.Controls.Add(this.lblsignedupsuccessfull);
            this.grpboxsignup.Controls.Add(this.lblinvalid);
            this.grpboxsignup.Controls.Add(this.btnsignup);
            this.grpboxsignup.Controls.Add(this.txtboxrole);
            this.grpboxsignup.Controls.Add(this.txtboxpassword);
            this.grpboxsignup.Controls.Add(this.txtboxusername);
            this.grpboxsignup.Controls.Add(this.lblrole);
            this.grpboxsignup.Controls.Add(this.lblpassword);
            this.grpboxsignup.Controls.Add(this.lblusername);
            this.grpboxsignup.Controls.Add(this.lblsignup);
            this.grpboxsignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpboxsignup.Location = new System.Drawing.Point(541, 194);
            this.grpboxsignup.Name = "grpboxsignup";
            this.grpboxsignup.Size = new System.Drawing.Size(329, 501);
            this.grpboxsignup.TabIndex = 0;
            this.grpboxsignup.TabStop = false;
            // 
            // linklblsinin
            // 
            this.linklblsinin.AutoSize = true;
            this.linklblsinin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblsinin.LinkColor = System.Drawing.Color.Red;
            this.linklblsinin.Location = new System.Drawing.Point(206, 459);
            this.linklblsinin.Name = "linklblsinin";
            this.linklblsinin.Size = new System.Drawing.Size(51, 17);
            this.linklblsinin.TabIndex = 11;
            this.linklblsinin.TabStop = true;
            this.linklblsinin.Text = "Sign In";
            this.linklblsinin.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linklblsinin_LinkClicked);
            // 
            // lblalredyhaveaccount
            // 
            this.lblalredyhaveaccount.AutoSize = true;
            this.lblalredyhaveaccount.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblalredyhaveaccount.ForeColor = System.Drawing.Color.Snow;
            this.lblalredyhaveaccount.Location = new System.Drawing.Point(35, 455);
            this.lblalredyhaveaccount.Name = "lblalredyhaveaccount";
            this.lblalredyhaveaccount.Size = new System.Drawing.Size(165, 17);
            this.lblalredyhaveaccount.TabIndex = 10;
            this.lblalredyhaveaccount.Text = "Already have an account";
            // 
            // lblsignedupsuccessfull
            // 
            this.lblsignedupsuccessfull.AutoSize = true;
            this.lblsignedupsuccessfull.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsignedupsuccessfull.ForeColor = System.Drawing.Color.Red;
            this.lblsignedupsuccessfull.Location = new System.Drawing.Point(90, 417);
            this.lblsignedupsuccessfull.Name = "lblsignedupsuccessfull";
            this.lblsignedupsuccessfull.Size = new System.Drawing.Size(145, 17);
            this.lblsignedupsuccessfull.TabIndex = 9;
            this.lblsignedupsuccessfull.Text = "SignedUp Successfull";
            this.lblsignedupsuccessfull.Visible = false;
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(39, 390);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(239, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Username, Password Or Role";
            this.lblinvalid.Visible = false;
            // 
            // btnsignup
            // 
            this.btnsignup.BackColor = System.Drawing.Color.Transparent;
            this.btnsignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsignup.Location = new System.Drawing.Point(93, 358);
            this.btnsignup.Name = "btnsignup";
            this.btnsignup.Size = new System.Drawing.Size(134, 29);
            this.btnsignup.TabIndex = 7;
            this.btnsignup.Text = "Sign Up";
            this.btnsignup.UseVisualStyleBackColor = false;
            this.btnsignup.Click += new System.EventHandler(this.btnsignup_Click);
            // 
            // txtboxrole
            // 
            this.txtboxrole.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxrole.Location = new System.Drawing.Point(37, 291);
            this.txtboxrole.Name = "txtboxrole";
            this.txtboxrole.Size = new System.Drawing.Size(241, 26);
            this.txtboxrole.TabIndex = 6;
            this.txtboxrole.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // txtboxpassword
            // 
            this.txtboxpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxpassword.Location = new System.Drawing.Point(37, 228);
            this.txtboxpassword.Name = "txtboxpassword";
            this.txtboxpassword.Size = new System.Drawing.Size(241, 26);
            this.txtboxpassword.TabIndex = 5;
            // 
            // txtboxusername
            // 
            this.txtboxusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxusername.Location = new System.Drawing.Point(37, 165);
            this.txtboxusername.Name = "txtboxusername";
            this.txtboxusername.Size = new System.Drawing.Size(241, 26);
            this.txtboxusername.TabIndex = 4;
            // 
            // lblrole
            // 
            this.lblrole.AutoSize = true;
            this.lblrole.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblrole.ForeColor = System.Drawing.SystemColors.Control;
            this.lblrole.Location = new System.Drawing.Point(34, 260);
            this.lblrole.Name = "lblrole";
            this.lblrole.Size = new System.Drawing.Size(37, 17);
            this.lblrole.TabIndex = 3;
            this.lblrole.Text = "Role";
            this.lblrole.Click += new System.EventHandler(this.label5_Click);
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lblpassword.Location = new System.Drawing.Point(34, 199);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(69, 17);
            this.lblpassword.TabIndex = 2;
            this.lblpassword.Text = "Password";
            this.lblpassword.Click += new System.EventHandler(this.label4_Click);
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.SystemColors.Control;
            this.lblusername.Location = new System.Drawing.Point(34, 132);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(73, 17);
            this.lblusername.TabIndex = 1;
            this.lblusername.Text = "Username";
            // 
            // lblsignup
            // 
            this.lblsignup.AutoSize = true;
            this.lblsignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsignup.ForeColor = System.Drawing.SystemColors.Control;
            this.lblsignup.Location = new System.Drawing.Point(110, 48);
            this.lblsignup.Name = "lblsignup";
            this.lblsignup.Size = new System.Drawing.Size(117, 31);
            this.lblsignup.TabIndex = 0;
            this.lblsignup.Text = "Sign Up";
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(437, 81);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // SignUp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Controls.Add(this.grpboxsignup);
            this.ForeColor = System.Drawing.Color.OrangeRed;
            this.Name = "SignUp";
            this.Text = "SignUp";
            this.Load += new System.EventHandler(this.SignUp_Load);
            this.grpboxsignup.ResumeLayout(false);
            this.grpboxsignup.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox grpboxsignup;
        private System.Windows.Forms.Label lblrole;
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblsignup;
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.TextBox txtboxrole;
        private System.Windows.Forms.TextBox txtboxpassword;
        private System.Windows.Forms.TextBox txtboxusername;
        private System.Windows.Forms.Button btnsignup;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Label lblsignedupsuccessfull;
        private System.Windows.Forms.LinkLabel linklblsinin;
        private System.Windows.Forms.Label lblalredyhaveaccount;
    }
}
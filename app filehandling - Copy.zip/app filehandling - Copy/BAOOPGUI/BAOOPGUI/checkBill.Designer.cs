﻿namespace BAOOPGUI
{
    partial class checkBill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxcheckbill = new System.Windows.Forms.GroupBox();
            this.checkBoxcheckbill = new System.Windows.Forms.CheckBox();
            this.lblmedadded = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblmedquantity = new System.Windows.Forms.Label();
            this.txtboxmedquantity = new System.Windows.Forms.TextBox();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btnaddstock = new System.Windows.Forms.Button();
            this.txtboxmedname = new System.Windows.Forms.TextBox();
            this.lblmedname = new System.Windows.Forms.Label();
            this.lblcheckbill = new System.Windows.Forms.Label();
            this.grpboxcheckbill.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(412, 95);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxcheckbill
            // 
            this.grpboxcheckbill.BackColor = System.Drawing.Color.Transparent;
            this.grpboxcheckbill.Controls.Add(this.checkBoxcheckbill);
            this.grpboxcheckbill.Controls.Add(this.lblmedadded);
            this.grpboxcheckbill.Controls.Add(this.btnexit);
            this.grpboxcheckbill.Controls.Add(this.lblmedquantity);
            this.grpboxcheckbill.Controls.Add(this.txtboxmedquantity);
            this.grpboxcheckbill.Controls.Add(this.lblinvalid);
            this.grpboxcheckbill.Controls.Add(this.btnaddstock);
            this.grpboxcheckbill.Controls.Add(this.txtboxmedname);
            this.grpboxcheckbill.Controls.Add(this.lblmedname);
            this.grpboxcheckbill.Controls.Add(this.lblcheckbill);
            this.grpboxcheckbill.Location = new System.Drawing.Point(382, 189);
            this.grpboxcheckbill.Name = "grpboxcheckbill";
            this.grpboxcheckbill.Size = new System.Drawing.Size(673, 491);
            this.grpboxcheckbill.TabIndex = 8;
            this.grpboxcheckbill.TabStop = false;
            // 
            // checkBoxcheckbill
            // 
            this.checkBoxcheckbill.AutoSize = true;
            this.checkBoxcheckbill.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.checkBoxcheckbill.ForeColor = System.Drawing.Color.Black;
            this.checkBoxcheckbill.Location = new System.Drawing.Point(187, 301);
            this.checkBoxcheckbill.Name = "checkBoxcheckbill";
            this.checkBoxcheckbill.Size = new System.Drawing.Size(268, 21);
            this.checkBoxcheckbill.TabIndex = 15;
            this.checkBoxcheckbill.Text = "Do You Want To Add more Medicines.";
            this.checkBoxcheckbill.UseVisualStyleBackColor = true;
            this.checkBoxcheckbill.CheckedChanged += new System.EventHandler(this.checkBox1_CheckedChanged);
            // 
            // lblmedadded
            // 
            this.lblmedadded.AutoSize = true;
            this.lblmedadded.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedadded.ForeColor = System.Drawing.Color.Red;
            this.lblmedadded.Location = new System.Drawing.Point(308, 460);
            this.lblmedadded.Name = "lblmedadded";
            this.lblmedadded.Size = new System.Drawing.Size(109, 17);
            this.lblmedadded.TabIndex = 14;
            this.lblmedadded.Text = "Medicine Added";
            this.lblmedadded.Visible = false;
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(443, 347);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(127, 33);
            this.btnexit.TabIndex = 12;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblmedquantity
            // 
            this.lblmedquantity.AutoSize = true;
            this.lblmedquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedquantity.ForeColor = System.Drawing.Color.Black;
            this.lblmedquantity.Location = new System.Drawing.Point(34, 243);
            this.lblmedquantity.Name = "lblmedquantity";
            this.lblmedquantity.Size = new System.Drawing.Size(121, 17);
            this.lblmedquantity.TabIndex = 11;
            this.lblmedquantity.Text = "Medicine Quantity";
            // 
            // txtboxmedquantity
            // 
            this.txtboxmedquantity.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedquantity.Location = new System.Drawing.Point(161, 237);
            this.txtboxmedquantity.Name = "txtboxmedquantity";
            this.txtboxmedquantity.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedquantity.TabIndex = 10;
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(308, 443);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            // 
            // btnaddstock
            // 
            this.btnaddstock.BackColor = System.Drawing.Color.Transparent;
            this.btnaddstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddstock.Location = new System.Drawing.Point(161, 347);
            this.btnaddstock.Name = "btnaddstock";
            this.btnaddstock.Size = new System.Drawing.Size(127, 33);
            this.btnaddstock.TabIndex = 5;
            this.btnaddstock.Text = "Add";
            this.btnaddstock.UseVisualStyleBackColor = false;
            this.btnaddstock.Click += new System.EventHandler(this.btnaddstock_Click);
            // 
            // txtboxmedname
            // 
            this.txtboxmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedname.Location = new System.Drawing.Point(161, 139);
            this.txtboxmedname.Name = "txtboxmedname";
            this.txtboxmedname.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedname.TabIndex = 3;
            // 
            // lblmedname
            // 
            this.lblmedname.AutoSize = true;
            this.lblmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedname.ForeColor = System.Drawing.Color.Black;
            this.lblmedname.Location = new System.Drawing.Point(34, 145);
            this.lblmedname.Name = "lblmedname";
            this.lblmedname.Size = new System.Drawing.Size(105, 17);
            this.lblmedname.TabIndex = 1;
            this.lblmedname.Text = "Medicine Name";
            // 
            // lblcheckbill
            // 
            this.lblcheckbill.AutoSize = true;
            this.lblcheckbill.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcheckbill.ForeColor = System.Drawing.Color.Teal;
            this.lblcheckbill.Location = new System.Drawing.Point(275, 41);
            this.lblcheckbill.Name = "lblcheckbill";
            this.lblcheckbill.Size = new System.Drawing.Size(145, 31);
            this.lblcheckbill.TabIndex = 0;
            this.lblcheckbill.Text = "Check Bill";
            // 
            // checkBill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxcheckbill);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "checkBill";
            this.Text = "checkBill";
            this.grpboxcheckbill.ResumeLayout(false);
            this.grpboxcheckbill.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxcheckbill;
        private System.Windows.Forms.Label lblmedadded;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblmedquantity;
        private System.Windows.Forms.TextBox txtboxmedquantity;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Button btnaddstock;
        private System.Windows.Forms.TextBox txtboxmedname;
        private System.Windows.Forms.Label lblmedname;
        private System.Windows.Forms.Label lblcheckbill;
        private System.Windows.Forms.CheckBox checkBoxcheckbill;
    }
}
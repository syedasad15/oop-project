﻿namespace BAOOPGUI
{
    partial class customerMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lbladdstock = new System.Windows.Forms.Label();
            this.btngivefeedback = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            this.btncheckbill = new System.Windows.Forms.Button();
            this.btncheckprices = new System.Windows.Forms.Button();
            this.btnupdatepassword = new System.Windows.Forms.Button();
            this.lblcustomermenu = new System.Windows.Forms.Label();
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Transparent;
            this.groupBox1.Controls.Add(this.lbladdstock);
            this.groupBox1.Controls.Add(this.btngivefeedback);
            this.groupBox1.Controls.Add(this.btnexit);
            this.groupBox1.Controls.Add(this.btncheckbill);
            this.groupBox1.Controls.Add(this.btncheckprices);
            this.groupBox1.Controls.Add(this.btnupdatepassword);
            this.groupBox1.Controls.Add(this.lblcustomermenu);
            this.groupBox1.Location = new System.Drawing.Point(474, 150);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(430, 527);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            // 
            // lbladdstock
            // 
            this.lbladdstock.AutoSize = true;
            this.lbladdstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbladdstock.ForeColor = System.Drawing.Color.Teal;
            this.lbladdstock.Location = new System.Drawing.Point(111, 47);
            this.lbladdstock.Name = "lbladdstock";
            this.lbladdstock.Size = new System.Drawing.Size(219, 31);
            this.lbladdstock.TabIndex = 17;
            this.lbladdstock.Text = "Customer Menu";
            // 
            // btngivefeedback
            // 
            this.btngivefeedback.BackColor = System.Drawing.Color.Transparent;
            this.btngivefeedback.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btngivefeedback.Location = new System.Drawing.Point(130, 394);
            this.btngivefeedback.Name = "btngivefeedback";
            this.btngivefeedback.Size = new System.Drawing.Size(169, 34);
            this.btngivefeedback.TabIndex = 16;
            this.btngivefeedback.Text = "Give Feeback";
            this.btngivefeedback.UseVisualStyleBackColor = false;
            this.btngivefeedback.Click += new System.EventHandler(this.btngivefeedback_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(130, 472);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(169, 33);
            this.btnexit.TabIndex = 15;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // btncheckbill
            // 
            this.btncheckbill.BackColor = System.Drawing.Color.Transparent;
            this.btncheckbill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncheckbill.Location = new System.Drawing.Point(130, 138);
            this.btncheckbill.Name = "btncheckbill";
            this.btncheckbill.Size = new System.Drawing.Size(169, 33);
            this.btncheckbill.TabIndex = 14;
            this.btncheckbill.Text = "Check Bill";
            this.btncheckbill.UseVisualStyleBackColor = false;
            this.btncheckbill.Click += new System.EventHandler(this.btncheckbill_Click);
            // 
            // btncheckprices
            // 
            this.btncheckprices.BackColor = System.Drawing.Color.Transparent;
            this.btncheckprices.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btncheckprices.Location = new System.Drawing.Point(130, 314);
            this.btncheckprices.Name = "btncheckprices";
            this.btncheckprices.Size = new System.Drawing.Size(169, 34);
            this.btncheckprices.TabIndex = 13;
            this.btncheckprices.Text = "Check Prices";
            this.btncheckprices.UseVisualStyleBackColor = false;
            this.btncheckprices.Click += new System.EventHandler(this.btncheckprices_Click);
            // 
            // btnupdatepassword
            // 
            this.btnupdatepassword.BackColor = System.Drawing.Color.Transparent;
            this.btnupdatepassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatepassword.Location = new System.Drawing.Point(130, 228);
            this.btnupdatepassword.Name = "btnupdatepassword";
            this.btnupdatepassword.Size = new System.Drawing.Size(169, 33);
            this.btnupdatepassword.TabIndex = 12;
            this.btnupdatepassword.Text = "Update Password";
            this.btnupdatepassword.UseVisualStyleBackColor = false;
            this.btnupdatepassword.Click += new System.EventHandler(this.btnupdatepassword_Click);
            // 
            // lblcustomermenu
            // 
            this.lblcustomermenu.AutoSize = true;
            this.lblcustomermenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcustomermenu.ForeColor = System.Drawing.SystemColors.Control;
            this.lblcustomermenu.Location = new System.Drawing.Point(762, 29);
            this.lblcustomermenu.Name = "lblcustomermenu";
            this.lblcustomermenu.Size = new System.Drawing.Size(271, 39);
            this.lblcustomermenu.TabIndex = 0;
            this.lblcustomermenu.Text = "Customer Menu";
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(369, 40);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // customerMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Controls.Add(this.groupBox1);
            this.Name = "customerMenu";
            this.Text = "customerMenu";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Button btncheckbill;
        private System.Windows.Forms.Button btncheckprices;
        private System.Windows.Forms.Button btnupdatepassword;
        private System.Windows.Forms.Label lblcustomermenu;
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.Button btngivefeedback;
        private System.Windows.Forms.Label lbladdstock;
    }
}
﻿using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class changePasswordCustomer : Form
    {
        public changePasswordCustomer()
        {
            InitializeComponent();
        }

        private void grpboxchangepasswordcustomer_Enter(object sender, EventArgs e)
        {

        }

        private void btnupdatestock_Click(object sender, EventArgs e)
        {
            string originalName = txtboxoriginalname.Text;
            string oldPassword = txtboxoldpassword.Text;
            string newPassword = txtboxnewpassword.Text;
            int index = UserDL.getIndex(originalName, oldPassword);
            if(newPassword != string.Empty && index != -1 )
            {
                UserDL.updatePass(index, newPassword);
                UserDL.AddUserDataINFile("user.txt");
                lblupdatedsuccessfully.Visible = true;
                MessageBox.Show("Updated Successfully.");
                this.Close();
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invalid Credentials.");
                this.Close();
            }
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

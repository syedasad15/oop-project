﻿namespace BAOOPGUI
{
    partial class showStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridViewshowStock = new System.Windows.Forms.DataGridView();
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.btnaddstock = new System.Windows.Forms.Button();
            this.btndeletestock = new System.Windows.Forms.Button();
            this.btnupdatestock = new System.Windows.Forms.Button();
            this.btnexit = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewshowStock)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewshowStock
            // 
            this.dataGridViewshowStock.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewshowStock.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.dataGridViewshowStock.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridViewshowStock.Location = new System.Drawing.Point(383, 157);
            this.dataGridViewshowStock.Name = "dataGridViewshowStock";
            this.dataGridViewshowStock.ReadOnly = true;
            this.dataGridViewshowStock.Size = new System.Drawing.Size(613, 351);
            this.dataGridViewshowStock.TabIndex = 0;
            this.dataGridViewshowStock.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.WhiteSmoke;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(377, 53);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // btnaddstock
            // 
            this.btnaddstock.BackColor = System.Drawing.Color.Transparent;
            this.btnaddstock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnaddstock.Location = new System.Drawing.Point(383, 572);
            this.btnaddstock.Name = "btnaddstock";
            this.btnaddstock.Size = new System.Drawing.Size(156, 33);
            this.btnaddstock.TabIndex = 16;
            this.btnaddstock.Text = "Add Stock";
            this.btnaddstock.UseVisualStyleBackColor = false;
            this.btnaddstock.Click += new System.EventHandler(this.btnaddstock_Click);
            // 
            // btndeletestock
            // 
            this.btndeletestock.BackColor = System.Drawing.Color.Transparent;
            this.btndeletestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btndeletestock.Location = new System.Drawing.Point(612, 572);
            this.btndeletestock.Name = "btndeletestock";
            this.btndeletestock.Size = new System.Drawing.Size(156, 33);
            this.btndeletestock.TabIndex = 17;
            this.btndeletestock.Text = "Delete Stock";
            this.btndeletestock.UseVisualStyleBackColor = false;
            this.btndeletestock.Click += new System.EventHandler(this.btndeletestock_Click);
            // 
            // btnupdatestock
            // 
            this.btnupdatestock.BackColor = System.Drawing.Color.Transparent;
            this.btnupdatestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatestock.Location = new System.Drawing.Point(840, 572);
            this.btnupdatestock.Name = "btnupdatestock";
            this.btnupdatestock.Size = new System.Drawing.Size(156, 33);
            this.btnupdatestock.TabIndex = 18;
            this.btnupdatestock.Text = "Update Stock";
            this.btnupdatestock.UseVisualStyleBackColor = false;
            this.btnupdatestock.Click += new System.EventHandler(this.btnupdatestock_Click);
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(612, 631);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(156, 33);
            this.btnexit.TabIndex = 19;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // showStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.btnexit);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Controls.Add(this.btnupdatestock);
            this.Controls.Add(this.btndeletestock);
            this.Controls.Add(this.btnaddstock);
            this.Controls.Add(this.dataGridViewshowStock);
            this.Name = "showStock";
            this.Text = "showStock";
            this.Load += new System.EventHandler(this.showStock_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewshowStock)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridViewshowStock;
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.Button btnaddstock;
        private System.Windows.Forms.Button btndeletestock;
        private System.Windows.Forms.Button btnupdatestock;
        private System.Windows.Forms.Button btnexit;
    }
}
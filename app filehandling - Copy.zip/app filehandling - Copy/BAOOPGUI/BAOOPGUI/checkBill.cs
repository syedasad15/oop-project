﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class checkBill : Form
    {
        customer customer = new customer("",3);
        public checkBill()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnaddstock_Click(object sender, EventArgs e)
        {
            string name = txtboxmedname.Text;
            string quantity = (txtboxmedquantity.Text);
            bool flag = customer.checkInt(quantity);
            if (flag == true && quantity != string.Empty)
            {
                if (name != string.Empty)
                {
                    
                    int totalBill = 0;
                    int quantityyy = int.Parse(quantity);
                    if(quantityyy > 0)
                    {
                        customer c = new customer(name, quantityyy);
                        if (c != null)
                        {
                            bool flaggg = pharmacyDL.checkIfMedicinePresentInEnoughAmount(c);
                            if (flaggg == true)
                            {
                                int index = pharmacyDL.getIndex(c.getName());

                                int price = pharmacyDL.calculateBillOfSingleMedicine(index, c.getQuantity());
                                pharmacyDL.addMedicineInFile("medicine.txt");
                                c.setProductPrice(price);
                                customerDL.addInCustList(c);
                                customer.addProductInCart(c);
                                totalBill = customer.calculateLBill();
                                if (c.getQuantity() <= 0)
                                {
                                    pharmacyDL.removeMedicineFromList(index);

                                    pharmacyDL.addMedicineInFile("medicine.txt");
                                    MessageBox.Show("Medicine Removed successfully", "Removed", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                }
                                if(checkBoxcheckbill.Checked)
                                {
                                    txtboxmedname.Text = string.Empty;
                                    txtboxmedquantity.Text = string.Empty;
                                    checkBoxcheckbill.Checked = false;
                                }
                                else
                                {
                                    if (totalBill >= 1000)
                                    {
                                        this.Hide();
                                        Form showbill = new showBill(totalBill, name,customer.getCartList());
                                        showbill.ShowDialog();
                                        this.Show();
                                        customerDL.custList.Clear();
                                    }
                                    else if (totalBill > 0)
                                    {
                                        this.Hide();
                                        Form showbill = new showBill(totalBill, name, customer.getCartList());
                                        showbill.ShowDialog();
                                        this.Show();
                                        customerDL.custList.Clear();
                                    }
                                    else if (totalBill == 0)
                                    {
                                        MessageBox.Show("Nothing Purchased");
                                    }
                                    //else
                                    //{
                                    //    customerDL.custList.Clear();
                                    //}
                                }
                            }
                            else
                            {
                                MessageBox.Show("Medicine Not Present In Enough Amount");
                            }
                        }
                        else
                        {
                            MessageBox.Show("c is Null");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Itni medicine nai hy bsdk", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    
                }
                else
                {
                  MessageBox.Show("Invalid Input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    /*if(result == DialogResult.Yes)
                    {

                    }*/
                }
            }
            else
            {
                MessageBox.Show("Invalid Input", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}

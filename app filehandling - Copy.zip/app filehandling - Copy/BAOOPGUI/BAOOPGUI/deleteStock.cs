﻿using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class deleteStock : Form
    {
        public deleteStock()
        {
            InitializeComponent();
        }

        private void btndeletestock_Click(object sender, EventArgs e)
        {
            string name = txtboxmedname.Text;
            int index = pharmacyDL.getIndex(name);
            if (index == -1 || index != 0)
            {
                pharmacyDL.removeMedicineFromList(index);
                pharmacyDL.addMedicineInFile("medicine.txt");
                lbldeletestock.Visible = true;
                MessageBox.Show("Medicine Deleted");
                reset();
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invalid Input");
                reset();
            }
        }

        private void lblmeddeleted_Click(object sender, EventArgs e)
        {

        }
        private void reset()
        {
            txtboxmedname.Text = string.Empty;
            lbldeletestock.Visible = false;
            lblinvalid.Visible = false;
        }

        private void deleteStock_Load(object sender, EventArgs e)
        {
            pharmacyDL.readFromFile("medicine.txt");
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Hide();
            showStock show = new showStock();
            show.ShowDialog();
            this.Show();
        }
    }
}

﻿namespace BAOOPGUI
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblsignedinsuccessful = new System.Windows.Forms.Label();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.lbldonthaveaccount = new System.Windows.Forms.Label();
            this.linklblsignup = new System.Windows.Forms.LinkLabel();
            this.btnsignin = new System.Windows.Forms.Button();
            this.txtboxpassword = new System.Windows.Forms.TextBox();
            this.txtboxusername = new System.Windows.Forms.TextBox();
            this.lblpassword = new System.Windows.Forms.Label();
            this.lblusername = new System.Windows.Forms.Label();
            this.lblsignin = new System.Windows.Forms.Label();
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblsignedinsuccessful
            // 
            this.lblsignedinsuccessful.AutoSize = true;
            this.lblsignedinsuccessful.BackColor = System.Drawing.Color.Transparent;
            this.lblsignedinsuccessful.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsignedinsuccessful.ForeColor = System.Drawing.Color.Red;
            this.lblsignedinsuccessful.Location = new System.Drawing.Point(1154, 622);
            this.lblsignedinsuccessful.Name = "lblsignedinsuccessful";
            this.lblsignedinsuccessful.Size = new System.Drawing.Size(142, 17);
            this.lblsignedinsuccessful.TabIndex = 9;
            this.lblsignedinsuccessful.Text = "Signed in Successfull";
            this.lblsignedinsuccessful.Visible = false;
            this.lblsignedinsuccessful.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.BackColor = System.Drawing.Color.Transparent;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(1173, 659);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            // 
            // lbldonthaveaccount
            // 
            this.lbldonthaveaccount.AutoSize = true;
            this.lbldonthaveaccount.BackColor = System.Drawing.Color.Transparent;
            this.lbldonthaveaccount.ForeColor = System.Drawing.SystemColors.Control;
            this.lbldonthaveaccount.Location = new System.Drawing.Point(1058, 568);
            this.lbldonthaveaccount.Name = "lbldonthaveaccount";
            this.lbldonthaveaccount.Size = new System.Drawing.Size(119, 13);
            this.lbldonthaveaccount.TabIndex = 7;
            this.lbldonthaveaccount.Text = "Dont\'t have an account";
            // 
            // linklblsignup
            // 
            this.linklblsignup.AutoSize = true;
            this.linklblsignup.BackColor = System.Drawing.Color.Transparent;
            this.linklblsignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linklblsignup.ForeColor = System.Drawing.Color.Coral;
            this.linklblsignup.LinkColor = System.Drawing.Color.Orange;
            this.linklblsignup.Location = new System.Drawing.Point(1209, 566);
            this.linklblsignup.Name = "linklblsignup";
            this.linklblsignup.Size = new System.Drawing.Size(58, 17);
            this.linklblsignup.TabIndex = 6;
            this.linklblsignup.TabStop = true;
            this.linklblsignup.Text = "Sign Up";
            this.linklblsignup.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // btnsignin
            // 
            this.btnsignin.BackColor = System.Drawing.Color.Transparent;
            this.btnsignin.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnsignin.Location = new System.Drawing.Point(1176, 475);
            this.btnsignin.Name = "btnsignin";
            this.btnsignin.Size = new System.Drawing.Size(127, 33);
            this.btnsignin.TabIndex = 5;
            this.btnsignin.Text = "Sign In";
            this.btnsignin.UseVisualStyleBackColor = false;
            this.btnsignin.Click += new System.EventHandler(this.button1_Click);
            // 
            // txtboxpassword
            // 
            this.txtboxpassword.BackColor = System.Drawing.Color.Silver;
            this.txtboxpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxpassword.Location = new System.Drawing.Point(1091, 432);
            this.txtboxpassword.Name = "txtboxpassword";
            this.txtboxpassword.Size = new System.Drawing.Size(221, 26);
            this.txtboxpassword.TabIndex = 4;
            // 
            // txtboxusername
            // 
            this.txtboxusername.BackColor = System.Drawing.Color.Silver;
            this.txtboxusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxusername.Location = new System.Drawing.Point(1091, 355);
            this.txtboxusername.Name = "txtboxusername";
            this.txtboxusername.Size = new System.Drawing.Size(221, 26);
            this.txtboxusername.TabIndex = 3;
            // 
            // lblpassword
            // 
            this.lblpassword.AutoSize = true;
            this.lblpassword.BackColor = System.Drawing.Color.Transparent;
            this.lblpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpassword.ForeColor = System.Drawing.SystemColors.Control;
            this.lblpassword.Location = new System.Drawing.Point(992, 441);
            this.lblpassword.Name = "lblpassword";
            this.lblpassword.Size = new System.Drawing.Size(69, 17);
            this.lblpassword.TabIndex = 2;
            this.lblpassword.Text = "Password";
            // 
            // lblusername
            // 
            this.lblusername.AutoSize = true;
            this.lblusername.BackColor = System.Drawing.Color.Transparent;
            this.lblusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblusername.ForeColor = System.Drawing.SystemColors.Control;
            this.lblusername.Location = new System.Drawing.Point(992, 361);
            this.lblusername.Name = "lblusername";
            this.lblusername.Size = new System.Drawing.Size(73, 17);
            this.lblusername.TabIndex = 1;
            this.lblusername.Text = "Username";
            // 
            // lblsignin
            // 
            this.lblsignin.AutoSize = true;
            this.lblsignin.BackColor = System.Drawing.Color.Transparent;
            this.lblsignin.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsignin.ForeColor = System.Drawing.SystemColors.Control;
            this.lblsignin.Location = new System.Drawing.Point(1191, 263);
            this.lblsignin.Name = "lblsignin";
            this.lblsignin.Size = new System.Drawing.Size(105, 31);
            this.lblsignin.TabIndex = 0;
            this.lblsignin.Text = "Sign In";
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(408, 77);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            this.lblmsnpharmacy.Click += new System.EventHandler(this.label1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.lblinvalid);
            this.Controls.Add(this.lblsignedinsuccessful);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Controls.Add(this.linklblsignup);
            this.Controls.Add(this.lbldonthaveaccount);
            this.Controls.Add(this.lblsignin);
            this.Controls.Add(this.lblusername);
            this.Controls.Add(this.btnsignin);
            this.Controls.Add(this.txtboxusername);
            this.Controls.Add(this.txtboxpassword);
            this.Controls.Add(this.lblpassword);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblpassword;
        private System.Windows.Forms.Label lblusername;
        private System.Windows.Forms.Label lblsignin;
        private System.Windows.Forms.Label lbldonthaveaccount;
        private System.Windows.Forms.LinkLabel linklblsignup;
        private System.Windows.Forms.Button btnsignin;
        private System.Windows.Forms.TextBox txtboxpassword;
        private System.Windows.Forms.TextBox txtboxusername;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Label lblsignedinsuccessful;
        private System.Windows.Forms.Label lblmsnpharmacy;
    }
}


﻿using buisnessApplicationOOP.BL;
using buisnessApplicationOOP.DL;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class addStock : Form
    {
        public addStock()
        {
            InitializeComponent();
        }
        private bool checkInt(string item)
        {
            bool flag = false;
            int count = 0;
            foreach (var i in item)
            {
                int num = i - '0';
                if (num >= 0 && num <= 9)
                {
                    count++;
                }
            }
            if (count == item.Length)
            {
                flag = true;
            }
            return flag;
        }

        private void btnaddstock_Click(object sender, EventArgs e)
        {
            manager m1 = takeInput();
            if(m1 != null)
            {
                pharmacyDL.addMedicineInList(m1);
                pharmacyDL.addMedicineInFile("medicine.txt");
                lblmedadded.Visible = true;
                MessageBox.Show("Medicine added");
                reset();
            }
            else
            {
                lblinvalid.Visible = true;
                MessageBox.Show("Invaid");
                reset();
            }
        }
        private void reset()
        {
            txtboxmedname.Text = string.Empty;
            txtboxmedprice.Text = string.Empty;
            txtboxmedquantity.Text = string.Empty;
            lblinvalid.Visible = false;
            lblmedadded.Visible = false;
            lblalredyexit.Visible = false;
        }
        private manager takeInput()
        {
            string name = txtboxmedname.Text;
            string price = txtboxmedprice.Text;
            string quantity = txtboxmedquantity.Text;
            bool flag1 = checkInt(price);
            bool flag2 = checkInt(quantity);
            if (flag1 == true && flag2 == true && name != string.Empty && price != string.Empty && quantity != string.Empty)
            {
                int priceee = int.Parse(price);
                int quantityyy = int.Parse(quantity);
                manager m1 = new manager(name, priceee, quantityyy);
                bool flag = pharmacyDL.checkIfmedAlreadyExists(m1);
                if (flag)
                {
                    return m1;
                }
                else
                {
                    lblalredyexit.Visible = true;

                }
            }
            else
            {
                lblinvalid.Visible = true;
            }
            return null;
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Hide();
            showStock show = new showStock();
            show.ShowDialog();
            this.Show();

        }

        private void lblinvalid_Click(object sender, EventArgs e)
        {

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BAOOPGUI
{
    public partial class offerDiscount : Form
    {
        public offerDiscount()
        {
            InitializeComponent();
        }

        private void btnexit_Click(object sender, EventArgs e)
        {
            this.Hide();
            adminMenu adminMenu = new adminMenu();
            adminMenu.ShowDialog();
            this.Show();
        }

        private void offerDiscount_Load(object sender, EventArgs e)
        {

        }
    }
}

﻿namespace BAOOPGUI
{
    partial class updateStock
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxupdatestock = new System.Windows.Forms.GroupBox();
            this.lblmedupdated = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btnupdatestock = new System.Windows.Forms.Button();
            this.txtboxnewmedprice = new System.Windows.Forms.TextBox();
            this.txtboxmedname = new System.Windows.Forms.TextBox();
            this.lblmedprice = new System.Windows.Forms.Label();
            this.lblmedname = new System.Windows.Forms.Label();
            this.lblupdatestock = new System.Windows.Forms.Label();
            this.grpboxupdatestock.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(350, 78);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxupdatestock
            // 
            this.grpboxupdatestock.BackColor = System.Drawing.Color.Transparent;
            this.grpboxupdatestock.Controls.Add(this.lblmedupdated);
            this.grpboxupdatestock.Controls.Add(this.btnexit);
            this.grpboxupdatestock.Controls.Add(this.lblinvalid);
            this.grpboxupdatestock.Controls.Add(this.btnupdatestock);
            this.grpboxupdatestock.Controls.Add(this.txtboxnewmedprice);
            this.grpboxupdatestock.Controls.Add(this.txtboxmedname);
            this.grpboxupdatestock.Controls.Add(this.lblmedprice);
            this.grpboxupdatestock.Controls.Add(this.lblmedname);
            this.grpboxupdatestock.Controls.Add(this.lblupdatestock);
            this.grpboxupdatestock.Location = new System.Drawing.Point(319, 194);
            this.grpboxupdatestock.Name = "grpboxupdatestock";
            this.grpboxupdatestock.Size = new System.Drawing.Size(673, 491);
            this.grpboxupdatestock.TabIndex = 8;
            this.grpboxupdatestock.TabStop = false;
            // 
            // lblmedupdated
            // 
            this.lblmedupdated.AutoSize = true;
            this.lblmedupdated.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedupdated.ForeColor = System.Drawing.Color.Red;
            this.lblmedupdated.Location = new System.Drawing.Point(308, 426);
            this.lblmedupdated.Name = "lblmedupdated";
            this.lblmedupdated.Size = new System.Drawing.Size(122, 17);
            this.lblmedupdated.TabIndex = 14;
            this.lblmedupdated.Text = "Medicine Updated";
            this.lblmedupdated.Visible = false;
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(453, 360);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(127, 33);
            this.btnexit.TabIndex = 12;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(308, 443);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            // 
            // btnupdatestock
            // 
            this.btnupdatestock.BackColor = System.Drawing.Color.Transparent;
            this.btnupdatestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatestock.Location = new System.Drawing.Point(171, 360);
            this.btnupdatestock.Name = "btnupdatestock";
            this.btnupdatestock.Size = new System.Drawing.Size(127, 33);
            this.btnupdatestock.TabIndex = 5;
            this.btnupdatestock.Text = "Update";
            this.btnupdatestock.UseVisualStyleBackColor = false;
            this.btnupdatestock.Click += new System.EventHandler(this.btnupdatestock_Click);
            // 
            // txtboxnewmedprice
            // 
            this.txtboxnewmedprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxnewmedprice.Location = new System.Drawing.Point(171, 239);
            this.txtboxnewmedprice.Name = "txtboxnewmedprice";
            this.txtboxnewmedprice.Size = new System.Drawing.Size(409, 26);
            this.txtboxnewmedprice.TabIndex = 4;
            // 
            // txtboxmedname
            // 
            this.txtboxmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxmedname.Location = new System.Drawing.Point(171, 158);
            this.txtboxmedname.Name = "txtboxmedname";
            this.txtboxmedname.Size = new System.Drawing.Size(409, 26);
            this.txtboxmedname.TabIndex = 3;
            // 
            // lblmedprice
            // 
            this.lblmedprice.AutoSize = true;
            this.lblmedprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedprice.ForeColor = System.Drawing.Color.Black;
            this.lblmedprice.Location = new System.Drawing.Point(34, 245);
            this.lblmedprice.Name = "lblmedprice";
            this.lblmedprice.Size = new System.Drawing.Size(131, 17);
            this.lblmedprice.TabIndex = 2;
            this.lblmedprice.Text = "Medicine New Price";
            // 
            // lblmedname
            // 
            this.lblmedname.AutoSize = true;
            this.lblmedname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmedname.ForeColor = System.Drawing.Color.Black;
            this.lblmedname.Location = new System.Drawing.Point(34, 164);
            this.lblmedname.Name = "lblmedname";
            this.lblmedname.Size = new System.Drawing.Size(105, 17);
            this.lblmedname.TabIndex = 1;
            this.lblmedname.Text = "Medicine Name";
            // 
            // lblupdatestock
            // 
            this.lblupdatestock.AutoSize = true;
            this.lblupdatestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdatestock.ForeColor = System.Drawing.Color.Teal;
            this.lblupdatestock.Location = new System.Drawing.Point(275, 41);
            this.lblupdatestock.Name = "lblupdatestock";
            this.lblupdatestock.Size = new System.Drawing.Size(190, 31);
            this.lblupdatestock.TabIndex = 0;
            this.lblupdatestock.Text = "Update Stock";
            // 
            // updateStock
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxupdatestock);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "updateStock";
            this.Text = "updateStock";
            this.Load += new System.EventHandler(this.updateStock_Load);
            this.grpboxupdatestock.ResumeLayout(false);
            this.grpboxupdatestock.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxupdatestock;
        private System.Windows.Forms.Label lblmedupdated;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Button btnupdatestock;
        private System.Windows.Forms.TextBox txtboxnewmedprice;
        private System.Windows.Forms.TextBox txtboxmedname;
        private System.Windows.Forms.Label lblmedprice;
        private System.Windows.Forms.Label lblmedname;
        private System.Windows.Forms.Label lblupdatestock;
    }
}
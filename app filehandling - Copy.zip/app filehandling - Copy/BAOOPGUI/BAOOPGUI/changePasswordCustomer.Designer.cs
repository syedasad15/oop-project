﻿namespace BAOOPGUI
{
    partial class changePasswordCustomer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblmsnpharmacy = new System.Windows.Forms.Label();
            this.grpboxchangepasswordcustomer = new System.Windows.Forms.GroupBox();
            this.lblupdatedsuccessfully = new System.Windows.Forms.Label();
            this.txtboxoldpassword = new System.Windows.Forms.TextBox();
            this.lbloldpassword = new System.Windows.Forms.Label();
            this.btnexit = new System.Windows.Forms.Button();
            this.lblinvalid = new System.Windows.Forms.Label();
            this.btnupdatestock = new System.Windows.Forms.Button();
            this.txtboxnewpassword = new System.Windows.Forms.TextBox();
            this.txtboxoriginalname = new System.Windows.Forms.TextBox();
            this.lblnewpassword = new System.Windows.Forms.Label();
            this.lbloriginalusername = new System.Windows.Forms.Label();
            this.lblchangepasswordcustomer = new System.Windows.Forms.Label();
            this.grpboxchangepasswordcustomer.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblmsnpharmacy
            // 
            this.lblmsnpharmacy.AutoSize = true;
            this.lblmsnpharmacy.BackColor = System.Drawing.Color.Transparent;
            this.lblmsnpharmacy.Font = new System.Drawing.Font("Microsoft Sans Serif", 60F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblmsnpharmacy.ForeColor = System.Drawing.Color.Teal;
            this.lblmsnpharmacy.Location = new System.Drawing.Point(358, 89);
            this.lblmsnpharmacy.Name = "lblmsnpharmacy";
            this.lblmsnpharmacy.Size = new System.Drawing.Size(619, 91);
            this.lblmsnpharmacy.TabIndex = 1;
            this.lblmsnpharmacy.Text = "SA PHARMACY";
            // 
            // grpboxchangepasswordcustomer
            // 
            this.grpboxchangepasswordcustomer.BackColor = System.Drawing.Color.Transparent;
            this.grpboxchangepasswordcustomer.Controls.Add(this.lblupdatedsuccessfully);
            this.grpboxchangepasswordcustomer.Controls.Add(this.txtboxoldpassword);
            this.grpboxchangepasswordcustomer.Controls.Add(this.lbloldpassword);
            this.grpboxchangepasswordcustomer.Controls.Add(this.btnexit);
            this.grpboxchangepasswordcustomer.Controls.Add(this.lblinvalid);
            this.grpboxchangepasswordcustomer.Controls.Add(this.btnupdatestock);
            this.grpboxchangepasswordcustomer.Controls.Add(this.txtboxnewpassword);
            this.grpboxchangepasswordcustomer.Controls.Add(this.txtboxoriginalname);
            this.grpboxchangepasswordcustomer.Controls.Add(this.lblnewpassword);
            this.grpboxchangepasswordcustomer.Controls.Add(this.lbloriginalusername);
            this.grpboxchangepasswordcustomer.Controls.Add(this.lblchangepasswordcustomer);
            this.grpboxchangepasswordcustomer.ForeColor = System.Drawing.SystemColors.ControlText;
            this.grpboxchangepasswordcustomer.Location = new System.Drawing.Point(319, 194);
            this.grpboxchangepasswordcustomer.Name = "grpboxchangepasswordcustomer";
            this.grpboxchangepasswordcustomer.Size = new System.Drawing.Size(673, 491);
            this.grpboxchangepasswordcustomer.TabIndex = 9;
            this.grpboxchangepasswordcustomer.TabStop = false;
            this.grpboxchangepasswordcustomer.Enter += new System.EventHandler(this.grpboxchangepasswordcustomer_Enter);
            // 
            // lblupdatedsuccessfully
            // 
            this.lblupdatedsuccessfully.AutoSize = true;
            this.lblupdatedsuccessfully.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdatedsuccessfully.ForeColor = System.Drawing.Color.Red;
            this.lblupdatedsuccessfully.Location = new System.Drawing.Point(308, 426);
            this.lblupdatedsuccessfully.Name = "lblupdatedsuccessfully";
            this.lblupdatedsuccessfully.Size = new System.Drawing.Size(144, 17);
            this.lblupdatedsuccessfully.TabIndex = 17;
            this.lblupdatedsuccessfully.Text = "Updated Successfully";
            this.lblupdatedsuccessfully.Visible = false;
            // 
            // txtboxoldpassword
            // 
            this.txtboxoldpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxoldpassword.Location = new System.Drawing.Point(171, 207);
            this.txtboxoldpassword.Name = "txtboxoldpassword";
            this.txtboxoldpassword.Size = new System.Drawing.Size(409, 26);
            this.txtboxoldpassword.TabIndex = 16;
            // 
            // lbloldpassword
            // 
            this.lbloldpassword.AutoSize = true;
            this.lbloldpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloldpassword.ForeColor = System.Drawing.Color.Black;
            this.lbloldpassword.Location = new System.Drawing.Point(34, 213);
            this.lbloldpassword.Name = "lbloldpassword";
            this.lbloldpassword.Size = new System.Drawing.Size(95, 17);
            this.lbloldpassword.TabIndex = 15;
            this.lbloldpassword.Text = "Old Password";
            // 
            // btnexit
            // 
            this.btnexit.BackColor = System.Drawing.Color.Transparent;
            this.btnexit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnexit.Location = new System.Drawing.Point(453, 360);
            this.btnexit.Name = "btnexit";
            this.btnexit.Size = new System.Drawing.Size(127, 33);
            this.btnexit.TabIndex = 12;
            this.btnexit.Text = "Exit";
            this.btnexit.UseVisualStyleBackColor = false;
            this.btnexit.Click += new System.EventHandler(this.btnexit_Click);
            // 
            // lblinvalid
            // 
            this.lblinvalid.AutoSize = true;
            this.lblinvalid.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblinvalid.ForeColor = System.Drawing.Color.Red;
            this.lblinvalid.Location = new System.Drawing.Point(308, 443);
            this.lblinvalid.Name = "lblinvalid";
            this.lblinvalid.Size = new System.Drawing.Size(123, 17);
            this.lblinvalid.TabIndex = 8;
            this.lblinvalid.Text = "Invalid Credentials";
            this.lblinvalid.Visible = false;
            // 
            // btnupdatestock
            // 
            this.btnupdatestock.BackColor = System.Drawing.Color.Transparent;
            this.btnupdatestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnupdatestock.Location = new System.Drawing.Point(171, 360);
            this.btnupdatestock.Name = "btnupdatestock";
            this.btnupdatestock.Size = new System.Drawing.Size(127, 33);
            this.btnupdatestock.TabIndex = 5;
            this.btnupdatestock.Text = "Update";
            this.btnupdatestock.UseVisualStyleBackColor = false;
            this.btnupdatestock.Click += new System.EventHandler(this.btnupdatestock_Click);
            // 
            // txtboxnewpassword
            // 
            this.txtboxnewpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxnewpassword.Location = new System.Drawing.Point(171, 259);
            this.txtboxnewpassword.Name = "txtboxnewpassword";
            this.txtboxnewpassword.Size = new System.Drawing.Size(409, 26);
            this.txtboxnewpassword.TabIndex = 4;
            // 
            // txtboxoriginalname
            // 
            this.txtboxoriginalname.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtboxoriginalname.Location = new System.Drawing.Point(171, 158);
            this.txtboxoriginalname.Name = "txtboxoriginalname";
            this.txtboxoriginalname.Size = new System.Drawing.Size(409, 26);
            this.txtboxoriginalname.TabIndex = 3;
            // 
            // lblnewpassword
            // 
            this.lblnewpassword.AutoSize = true;
            this.lblnewpassword.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnewpassword.ForeColor = System.Drawing.Color.Black;
            this.lblnewpassword.Location = new System.Drawing.Point(34, 268);
            this.lblnewpassword.Name = "lblnewpassword";
            this.lblnewpassword.Size = new System.Drawing.Size(100, 17);
            this.lblnewpassword.TabIndex = 2;
            this.lblnewpassword.Text = "New Password";
            // 
            // lbloriginalusername
            // 
            this.lbloriginalusername.AutoSize = true;
            this.lbloriginalusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbloriginalusername.ForeColor = System.Drawing.Color.Black;
            this.lbloriginalusername.Location = new System.Drawing.Point(34, 164);
            this.lbloriginalusername.Name = "lbloriginalusername";
            this.lbloriginalusername.Size = new System.Drawing.Size(98, 17);
            this.lbloriginalusername.TabIndex = 1;
            this.lbloriginalusername.Text = "Original Name";
            // 
            // lblchangepasswordcustomer
            // 
            this.lblchangepasswordcustomer.AutoSize = true;
            this.lblchangepasswordcustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblchangepasswordcustomer.ForeColor = System.Drawing.Color.Teal;
            this.lblchangepasswordcustomer.Location = new System.Drawing.Point(275, 41);
            this.lblchangepasswordcustomer.Name = "lblchangepasswordcustomer";
            this.lblchangepasswordcustomer.Size = new System.Drawing.Size(244, 31);
            this.lblchangepasswordcustomer.TabIndex = 0;
            this.lblchangepasswordcustomer.Text = "Update Password";
            // 
            // changePasswordCustomer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::BAOOPGUI.Properties.Resources.istockphoto_1300036753_612x612;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1370, 749);
            this.Controls.Add(this.grpboxchangepasswordcustomer);
            this.Controls.Add(this.lblmsnpharmacy);
            this.Name = "changePasswordCustomer";
            this.Text = "changePasswordCustomer";
            this.grpboxchangepasswordcustomer.ResumeLayout(false);
            this.grpboxchangepasswordcustomer.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblmsnpharmacy;
        private System.Windows.Forms.GroupBox grpboxchangepasswordcustomer;
        private System.Windows.Forms.Button btnexit;
        private System.Windows.Forms.Label lblinvalid;
        private System.Windows.Forms.Button btnupdatestock;
        private System.Windows.Forms.TextBox txtboxnewpassword;
        private System.Windows.Forms.TextBox txtboxoriginalname;
        private System.Windows.Forms.Label lblnewpassword;
        private System.Windows.Forms.Label lbloriginalusername;
        private System.Windows.Forms.Label lblchangepasswordcustomer;
        private System.Windows.Forms.TextBox txtboxoldpassword;
        private System.Windows.Forms.Label lbloldpassword;
        private System.Windows.Forms.Label lblupdatedsuccessfully;
    }
}